(() => {
  document.addEventListener('click', (event) => {
    const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement && node.href);
    if (!link) return;
    try {
      const url = new URL(link.href, window.location.href);
      if (url.origin !== window.location.origin || url.pathname !== '/auth/discord') return;
      url.searchParams.set('origin', window.location.origin);
      link.href = url.toString();
    } catch {}
  }, true);
})();
