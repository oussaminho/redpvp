import { randomUUID } from 'node:crypto';

function credentials() {
  const { PAYPAL_CLIENT_ID: clientId, PAYPAL_CLIENT_SECRET: clientSecret } = process.env;
  if (!clientId || !clientSecret) throw new Error('PayPal is not configured yet.');
  const mode = process.env.PAYPAL_ENV === 'live' ? 'live' : 'sandbox';
  return { clientId, clientSecret, mode, api: mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com' };
}

async function accessToken() {
  const { clientId, clientSecret, api } = credentials();
  const response = await fetch(`${api}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
    signal: AbortSignal.timeout(15_000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || typeof result.access_token !== 'string') throw new Error('PayPal could not authorize this request.');
  return result.access_token;
}

async function paypalRequest(path, { method = 'GET', body, requestId } = {}) {
  const { api } = credentials();
  const token = await accessToken();
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'return=representation' };
  if (requestId) headers['PayPal-Request-Id'] = requestId.slice(0, 100);
  const response = await fetch(`${api}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(20_000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error('PayPal could not complete the payment request.');
    error.providerStatus = response.status;
    throw error;
  }
  return result;
}

export function paypalReady() {
  return Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);
}

export async function createPayPalOrder({ orderId, totalCents, currency = 'USD', returnUrl, cancelUrl }) {
  const value = (totalCents / 100).toFixed(2);
  return paypalRequest('/v2/checkout/orders', {
    method: 'POST',
    requestId: `redpvp-create-${orderId}`,
    body: {
      intent: 'CAPTURE',
      purchase_units: [{ reference_id: orderId, custom_id: orderId, invoice_id: `RED-${orderId}`, amount: { currency_code: currency, value } }],
      application_context: { return_url: returnUrl, cancel_url: cancelUrl, user_action: 'PAY_NOW' }
    }
  });
}

export async function capturePayPalOrder({ paypalOrderId, orderId }) {
  const id = String(paypalOrderId || '');
  if (!/^[A-Z0-9]+$/.test(id) || id.length > 36) throw new Error('The PayPal order reference is invalid.');
  return paypalRequest(`/v2/checkout/orders/${encodeURIComponent(id)}/capture`, {
    method: 'POST',
    requestId: `redpvp-capture-${orderId || randomUUID()}`,
    body: {}
  });
}
