import { randomUUID } from 'node:crypto';

function serviceConfig() {
  const base = process.env.MANUS_API_URL;
  const key = process.env.MANUS_API_KEY;
  if (!base || !key) throw new Error('Project storage is unavailable.');
  return { base: base.replace(/\/$/, ''), key };
}

async function presign(direction, objectKey) {
  const { base, key } = serviceConfig();
  const endpoint = new URL(`${base}/v1/storage/presign/${direction}`);
  endpoint.searchParams.set('path', objectKey);
  const response = await fetch(endpoint, {
    headers: { Authorization: `Bearer ${key}` },
    signal: AbortSignal.timeout(15_000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || typeof result.url !== 'string') throw new Error('Project storage could not prepare the file transfer.');
  return result.url;
}

export async function storeFile({ orderId, kind, buffer, contentType }) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('The uploaded file is empty.');
  const objectKey = `redpvp/${kind}/${orderId}/${randomUUID()}`;
  const url = await presign('put', objectKey);
  const response = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': contentType },
    body: buffer,
    signal: AbortSignal.timeout(30_000)
  });
  if (!response.ok) throw new Error('The file could not be stored.');
  return { objectKey, size: buffer.length, contentType };
}

export async function readStoredFile(objectKey) {
  const url = await presign('get', objectKey);
  const response = await fetch(url, { signal: AbortSignal.timeout(20_000) });
  if (!response.ok || !response.body) throw new Error('The stored file could not be read.');
  return response;
}
