let cachedStatus = null;
let cachedAt = 0;

export function futureExpiry(value, now = Date.now()) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return null;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) && timestamp > now ? new Date(timestamp) : null;
}

function configuredUrl(input) {
  const url = new URL(input);
  const local = url.hostname === 'localhost' || url.hostname === '127.0.0.1';
  if ((!local && url.protocol !== 'https:') || url.username || url.password || url.hash) throw new Error('Invalid MTA endpoint.');
  return url;
}

export async function getMtaStatus() {
  const endpoint = process.env.MTA_STATUS_URL;
  const now = Date.now();
  if (cachedStatus && now - cachedAt < 10_000) return cachedStatus;
  if (!endpoint) return { state: 'unavailable', online: false, players: null, capacity: null, configured: false, checkedAt: new Date(now).toISOString() };
  try {
    const url = configuredUrl(endpoint);
    const response = await fetch(url, {
      headers: process.env.MTA_API_TOKEN ? { Authorization: `Bearer ${process.env.MTA_API_TOKEN}` } : {},
      signal: AbortSignal.timeout(8_000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || typeof data.online !== 'boolean') throw new Error('Invalid MTA status response.');
    const players = Number.isSafeInteger(data.players) && data.players >= 0 && data.players <= 100_000 ? data.players : null;
    const capacity = Number.isSafeInteger(data.capacity) && data.capacity > 0 && data.capacity <= 100_000 ? data.capacity : null;
    cachedStatus = { state: data.online ? 'online' : 'offline', online: data.online, players, capacity, configured: true, checkedAt: new Date(now).toISOString() };
  } catch {
    cachedStatus = { state: 'unavailable', online: false, players: null, capacity: null, configured: true, checkedAt: new Date(now).toISOString() };
  }
  cachedAt = now;
  return cachedStatus;
}

export async function callMtaApi(endpoint, payload) {
  if (!process.env.MTA_API_TOKEN) throw new Error('MTA integration is not configured.');
  const url = configuredUrl(endpoint);
  const response = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.MTA_API_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(10_000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error('MTA server did not accept the request.');
  return result;
}
