const SITEVERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

export function turnstileReady() {
  return Boolean(process.env.TURNSTILE_SITE_KEY && process.env.TURNSTILE_SECRET_KEY);
}

export async function verifyTurnstile(responseToken, remoteIp) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret || !process.env.TURNSTILE_SITE_KEY) throw new Error('Turnstile is not configured yet.');
  if (typeof responseToken !== 'string' || responseToken.length < 1 || responseToken.length > 2048) return false;
  const body = new URLSearchParams({ secret, response: responseToken });
  if (remoteIp && remoteIp.length <= 64) body.set('remoteip', remoteIp);
  const response = await fetch(SITEVERIFY_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(10_000)
  });
  if (!response.ok) return false;
  const result = await response.json().catch(() => ({}));
  return result.success === true;
}
