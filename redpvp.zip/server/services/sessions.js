import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { query } from '../db/index.js';

const SESSION_COOKIE = 'redpvp_session';
const OAUTH_COOKIE = 'redpvp_oauth_state';
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 30;
const OAUTH_TTL_SECONDS = 60 * 10;

function signingSecret() {
  const secret = process.env.REDPVP_SESSION_SECRET;
  return typeof secret === 'string' && Buffer.byteLength(secret) >= 32 ? secret : null;
}

function cookieSecure() {
  return process.env.APP_COOKIE_SECURE !== 'false';
}

function cookieFlags({ httpOnly = true, maxAge, sameSite } = {}) {
  const parts = ['Path=/', 'SameSite=' + (sameSite || (cookieSecure() ? 'None' : 'Lax'))];
  if (httpOnly) parts.push('HttpOnly');
  if (cookieSecure()) parts.push('Secure');
  if (Number.isFinite(maxAge)) parts.push(`Max-Age=${Math.max(0, Math.floor(maxAge))}`);
  return parts.join('; ');
}

export function appendCookie(res, name, value, opts = {}) {
  const cookie = `${name}=${encodeURIComponent(value)}; ${cookieFlags(opts)}`;
  res.append('Set-Cookie', cookie);
}

export function clearCookie(res, name, opts = {}) {
  appendCookie(res, name, '', { ...opts, maxAge: 0 });
}

function readCookie(header, name) {
  for (const part of String(header || '').split(';')) {
    const at = part.indexOf('=');
    if (at < 0 || part.slice(0, at).trim() !== name) continue;
    try { return decodeURIComponent(part.slice(at + 1).trim()); } catch { return ''; }
  }
  return '';
}

const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const mac = (value) => createHmac('sha256', signingSecret() || 'missing-redpvp-secret').update(value).digest('hex');

function signedToken(raw) {
  return `${raw}.${mac(raw)}`;
}

function verifiedToken(value) {
  const [raw, signature, extra] = String(value || '').split('.');
  if (!raw || !signature || extra || !/^[a-f0-9]{64}$/.test(raw) || !/^[a-f0-9]{64}$/.test(signature)) return null;
  const actual = Buffer.from(mac(raw), 'hex');
  const given = Buffer.from(signature, 'hex');
  return actual.length === given.length && timingSafeEqual(actual, given) ? raw : null;
}

export async function getSession(cookieHeader) {
  const secret = signingSecret();
  const raw = secret && verifiedToken(readCookie(cookieHeader, SESSION_COOKIE));
  if (!raw) return null;
  const rows = await query(
    `SELECT s.csrf_token, s.expires_at, u.id, u.discord_id, u.username, u.avatar_url, u.game_username, u.role
     FROM app_sessions s JOIN app_users u ON u.id=s.user_id
     WHERE s.token_hash=? AND s.expires_at > UTC_TIMESTAMP() LIMIT 1`,
    [sha256(raw)]
  );
  if (!rows.length) return null;
  const row = rows[0];
  return {
    user: {
      id: Number(row.id),
      discordId: String(row.discord_id),
      username: row.username,
      avatar: row.avatar_url || '/assets/red-pvp-logo.png',
      gameUsername: row.game_username,
      role: row.role,
      isStaff: ['staff', 'admin'].includes(row.role),
      isAdmin: row.role === 'admin'
    },
    csrfToken: row.csrf_token,
    sessionHash: sha256(raw)
  };
}

export async function createSession(userId, res) {
  const secret = signingSecret();
  if (!secret) throw new Error('The application session secret is not configured.');
  const raw = randomBytes(32).toString('hex');
  const csrf = randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);
  await query('INSERT INTO app_sessions (token_hash, user_id, csrf_token, expires_at) VALUES (?, ?, ?, ?)', [sha256(raw), userId, csrf, expires]);
  appendCookie(res, SESSION_COOKIE, signedToken(raw), { maxAge: SESSION_TTL_SECONDS });
  return csrf;
}

export async function revokeSession(sessionHash) {
  if (sessionHash) await query('DELETE FROM app_sessions WHERE token_hash=?', [sessionHash]);
}

export function beginOAuthCookie(res, state) {
  appendCookie(res, OAUTH_COOKIE, state, { maxAge: OAUTH_TTL_SECONDS, sameSite: cookieSecure() ? 'Lax' : 'Lax' });
}

export function readOAuthCookie(header) {
  return readCookie(header, OAUTH_COOKIE);
}

export function clearOAuthCookie(res) {
  clearCookie(res, OAUTH_COOKIE, { sameSite: 'Lax' });
}

export function createOAuthState() {
  return randomBytes(32).toString('hex');
}

export const hashOAuthState = sha256;
