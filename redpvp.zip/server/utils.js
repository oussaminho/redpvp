import { randomUUID } from 'node:crypto';

export const uuid = () => randomUUID();
export const text = (value, max = 120) => typeof value === 'string' ? value.trim().slice(0, max) : '';
export const int = (value, min, max) => {
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= min && n <= max ? n : null;
};
export const money = (cents) => (Number(cents) / 100).toFixed(2);
export const jsonValue = (value, fallback) => {
  if (value && typeof value === 'object') return value;
  if (typeof value === 'string') { try { return JSON.parse(value); } catch { return fallback; } }
  return fallback;
};
export const errorStatus = (error) => Number.isInteger(error?.status) ? error.status : 400;

export function clientOrigin(req) {
  const input = text(req.body?.origin || req.query?.origin || req.get('origin') || req.get('referer'), 500);
  if (!input) return '';
  try {
    const url = new URL(input);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) return '';
    const allowed = (process.env.REDPVP_ALLOWED_ORIGINS || '').split(',').map((item) => item.trim()).filter(Boolean);
    if (allowed.length && !allowed.includes(url.origin)) return '';
    if (!allowed.length && url.hostname !== 'localhost' && url.hostname !== '127.0.0.1' && !url.hostname.endsWith('.manus.computer') && url.hostname !== 'red-pvp.site' && !url.hostname.endsWith('.red-pvp.site')) return '';
    return url.origin;
  } catch { return ''; }
}
