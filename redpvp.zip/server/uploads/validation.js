import { createHash } from 'node:crypto';

export function decodeBase64(value, maxBytes, message = 'The uploaded file is invalid.') {
  if (typeof value !== 'string' || value.length < 8 || value.length > Math.ceil(maxBytes * 4 / 3) + 256) throw new Error(message);
  const prefix = /^data:[^,]{1,220};base64,/i.exec(value);
  const base64 = prefix ? value.slice(prefix[0].length) : value;
  if (base64.length > Math.ceil(maxBytes * 4 / 3) || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(base64)) throw new Error(message);
  const buffer = Buffer.from(base64, 'base64');
  if (!buffer.length || buffer.length > maxBytes) throw new Error(message);
  return buffer;
}

export function isPng(buffer) {
  return buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
}
export function isJpeg(buffer) { return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff; }
export function isWebp(buffer) { return buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP'; }
export function receiptType(buffer) {
  if (isPng(buffer)) return 'image/png';
  if (isJpeg(buffer)) return 'image/jpeg';
  if (isWebp(buffer)) return 'image/webp';
  return null;
}
export function isZip(buffer) {
  return buffer.length >= 22 && buffer[0] === 0x50 && buffer[1] === 0x4b && [0x03, 0x05, 0x07].includes(buffer[2]) && [0x04, 0x06, 0x08].includes(buffer[3]);
}

export function zipEntries(buffer) {
  const lowerBound = Math.max(0, buffer.length - 65_557);
  let eocd = -1;
  for (let offset = buffer.length - 22; offset >= lowerBound; offset--) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) { eocd = offset; break; }
  }
  if (eocd < 0) throw new Error('The ZIP archive is incomplete.');
  const disk = buffer.readUInt16LE(eocd + 4);
  const centralDisk = buffer.readUInt16LE(eocd + 6);
  const diskEntries = buffer.readUInt16LE(eocd + 8);
  const totalEntries = buffer.readUInt16LE(eocd + 10);
  const centralSize = buffer.readUInt32LE(eocd + 12);
  const centralOffset = buffer.readUInt32LE(eocd + 16);
  const commentLength = buffer.readUInt16LE(eocd + 20);
  if (disk !== 0 || centralDisk !== 0 || diskEntries !== totalEntries || totalEntries < 1 || totalEntries > 20 || eocd + 22 + commentLength !== buffer.length || centralOffset + centralSize > eocd) throw new Error('The ZIP archive structure is not supported.');
  const names = [];
  let cursor = centralOffset;
  let expandedBytes = 0;
  for (let i = 0; i < totalEntries; i++) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== 0x02014b50) throw new Error('The ZIP archive structure is not supported.');
    const flags = buffer.readUInt16LE(cursor + 8);
    const method = buffer.readUInt16LE(cursor + 10);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const entryCommentLength = buffer.readUInt16LE(cursor + 32);
    const entryEnd = cursor + 46 + nameLength + extraLength + entryCommentLength;
    if (entryEnd > buffer.length || (flags & 1) || ![0, 8].includes(method) || nameLength < 1) throw new Error('The ZIP archive contains an unsupported entry.');
    const name = buffer.toString('utf8', cursor + 46, cursor + 46 + nameLength);
    if (!name || name.startsWith('/') || name.includes('\\') || name.split('/').some((part) => part === '..' || part === '.')) throw new Error('The ZIP archive contains an unsafe file path.');
    if (name.endsWith('/')) throw new Error('The ZIP archive may contain only the DFF and TXD files.');
    expandedBytes += uncompressedSize;
    if (expandedBytes > 50 * 1024 * 1024) throw new Error('The expanded ZIP archive exceeds the safe size limit.');
    names.push(name);
    cursor = entryEnd;
  }
  if (cursor !== centralOffset + centralSize) throw new Error('The ZIP archive structure is not supported.');
  return names;
}


export function validateSkinArchive(buffer) {
  if (!isZip(buffer)) throw new Error('The skin upload must be a valid ZIP archive.');
  const names = zipEntries(buffer).map((entry) => entry.toLowerCase());
  if (names.length !== 2 || names.filter((name) => name.endsWith('.dff')).length !== 1 || names.filter((name) => name.endsWith('.txd')).length !== 1) {
    throw new Error('The ZIP must contain exactly one DFF file and one TXD file.');
  }
  return buffer;
}

export function hashIp(ip) {
  const secret = process.env.REDPVP_SESSION_SECRET || process.env.MANUS_JWT_SECRET || 'redpvp-unconfigured-ip-hash';
  return createHash('sha256').update(`${secret}:${ip}`).digest('hex');
}
