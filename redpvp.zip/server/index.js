import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase } from './db/index.js';
import { attachUser } from './middleware/auth.js';
import authRoutes from './routes/auth.js';
import communityRoutes from './routes/community.js';
import gameRoutes from './routes/game.js';
import paymentRoutes from './routes/payments.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(here, '../public');
const app = express();
let ready = false;
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  frameguard: false,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
}));
function limit({ max, windowMs, message }) {
  const hits = new Map();
  return (req, res, next) => {
    const key = `${req.ip}:${req.baseUrl}${req.path}`;
    const now = Date.now();
    const entry = hits.get(key);
    if (!entry || now - entry.startedAt >= windowMs) hits.set(key, { startedAt: now, count: 1 });
    else if (++entry.count > max) return res.status(429).json({ error: message, retryAfterSeconds: Math.ceil((windowMs - (now - entry.startedAt)) / 1000) });
    if (hits.size > 10_000) for (const [candidate, value] of hits) if (now - value.startedAt > windowMs) hits.delete(candidate);
    next();
  };
}

app.use('/auth', limit({ max: 30, windowMs: 15 * 60_000, message: 'Too many sign-in requests. Try again shortly.' }));
app.use('/api', limit({ max: 180, windowMs: 60_000, message: 'Too many requests. Try again shortly.' }));
app.use('/api/payments', limit({ max: 24, windowMs: 60_000, message: 'Too many payment requests. Try again shortly.' }));


app.use(express.json({ limit: '18mb', strict: true }));

app.get('/healthz', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  if (!ready) return res.status(503).json({ status: 'starting' });
  res.json({ status: 'ok' });
});
app.get('/api/health', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.status(ready ? 200 : 503).json({ status: ready ? 'ok' : 'starting' });
});
app.use(['/auth', '/api'], (req, res, next) => {
  res.set('Cache-Control', 'private, no-store');
  attachUser(req, res, next);
});
app.use((req, res, next) => {
  if (!ready && (req.path.startsWith('/api/') || req.path.startsWith('/auth/'))) return res.status(503).json({ error: 'The RED PVP backend is starting. Retry shortly.' });
  next();
});
app.use('/auth', authRoutes);
app.use('/api', communityRoutes);
app.use('/api', gameRoutes);
app.use('/api', paymentRoutes);

const pageAliases = new Map([
  ['/about', 'about.html'], ['/creators', 'creators.html'], ['/dashboard', 'dashboard.html'],
  ['/leaderboard', 'leaderboard.html'], ['/partners', 'partners.html'], ['/privacy', 'privacy.html'],
  ['/request-content-creator', 'request-content-creator.html'], ['/server-status', 'server-status.html'],
  ['/shop', 'shop.html'], ['/staff', 'staff.html'], ['/terms', 'terms.html'], ['/verification', 'verification.html'],
  ['/orders', 'orders.html'], ['/admin/payments', 'admin-payments.html']
]);
for (const [route, file] of pageAliases) {
  app.get(route, (_req, res) => res.sendFile(path.join(publicDir, file)));
}

app.use(express.static(publicDir, {
  dotfiles: 'ignore',
  fallthrough: true,
  index: 'index.html',
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  setHeaders(res, filePath) {
    const base = path.basename(filePath);
    if (/\.(?:m?js)(?:@|$)/i.test(base)) res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    else if (/\.css(?:@|$)/i.test(base)) res.setHeader('Content-Type', 'text/css; charset=utf-8');
    else if (base === 'manus-routes.json') res.setHeader('Cache-Control', 'no-cache');
  }
}));

app.use((req, res) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) return res.status(404).json({ error: 'Route not found.' });
  res.status(404).type('text/plain').send('Page not found.');
});

app.use((error, _req, res, _next) => {
  if (res.headersSent) return;
  const status = Number.isInteger(error.status) && error.status >= 400 && error.status < 500 ? error.status : 500;
  if (status >= 500) console.error('Request failed', error.code || error.name || 'internal_error');
  res.status(status).json({ error: status < 500 ? error.message : 'The service is temporarily unavailable.' });
});

const port = Number(process.env.PORT) || 3000;
const server = app.listen(port, '0.0.0.0', () => console.log(`RED PVP server listening on ${port}`));

initializeDatabase().then(() => {
  ready = true;
  console.log('RED PVP database migrations are ready');
}).catch((error) => {
  console.error('RED PVP database initialization failed', error.code || 'migration_error');
});

async function shutdown(signal) {
  console.log(`Received ${signal}; closing RED PVP server`);
  ready = false;
  server.close(async () => {
    try { await closeDatabase(); } catch {}
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
