import { Router } from 'express';
import { query, withTransaction } from '../db/index.js';
import { normalizeCart, totalCartCents } from '../catalog.js';
import { requireAdmin, requireCsrf, requireStaff, requireUser } from '../middleware/auth.js';
import { capturePayPalOrder, createPayPalOrder, paypalReady } from '../services/paypal.js';
import { readStoredFile, storeFile } from '../services/storage.js';
import { decodeBase64, receiptType, validateSkinArchive } from '../uploads/validation.js';
import { int, money, text, uuid } from '../utils.js';
import { Readable } from 'node:stream';

const router = Router();
const MAX_PROOF_BYTES = 3 * 1024 * 1024;
const MAX_SKIN_BYTES = 10 * 1024 * 1024;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function cihRate() {
  const value = Number(process.env.CIH_RATE);
  return Number.isFinite(value) && value > 0 && value < 100_000 ? value : null;
}
function cihReady() {
  return Boolean(text(process.env.CIH_ACCOUNT_NAME, 100) && text(process.env.CIH_ACCOUNT_NUMBER, 100) && cihRate());
}
function publicOrder(row, items = [], proofs = [], skinFiles = []) {
  return {
    id: row.id,
    orderNum: Number(row.order_number),
    orderNumber: Number(row.order_number),
    method: row.method,
    status: row.status,
    fulfillment: row.fulfillment,
    currency: row.currency,
    total: money(row.total_cents),
    transferReference: row.transfer_reference,
    approvalUrl: row.paypal_approval_url || undefined,
    createdAt: row.created_at,
    items,
    proofs: proofs.map((file) => ({ id: file.id })),
    skinFiles: skinFiles.map((file) => ({ id: file.id }))
  };
}

async function orderForUser(id, userId) {
  if (!UUID_RE.test(String(id || ''))) return null;
  const rows = await query('SELECT * FROM red_orders WHERE id=? AND user_id=? LIMIT 1', [id, userId]);
  if (!rows.length) return null;
  const row = rows[0];
  const [items, files] = await Promise.all([
    query('SELECT product_id AS id, product_name AS name, plan_id AS planId, plan_label AS duration, quantity AS qty, car_name AS car, skin_name AS skin, weapon_name AS weapon, unit_cents, total_cents FROM red_order_items WHERE order_id=? ORDER BY id', [id]),
    query('SELECT id, file_kind FROM stored_user_files WHERE order_id=? ORDER BY created_at', [id])
  ]);
  return publicOrder(row, items, files.filter((file) => file.file_kind === 'proof'), files.filter((file) => file.file_kind === 'skin'));
}

async function orderForStaff(id) {
  if (!UUID_RE.test(String(id || ''))) return null;
  const rows = await query(
    `SELECT o.*, u.discord_id, u.username FROM red_orders o JOIN app_users u ON u.id=o.user_id WHERE o.id=? LIMIT 1`, [id]
  );
  if (!rows.length) return null;
  const row = rows[0];
  const [items, files] = await Promise.all([
    query('SELECT product_id AS id, product_name AS name, plan_id AS planId, plan_label AS duration, quantity AS qty, car_name AS car, skin_name AS skin, weapon_name AS weapon, unit_cents, total_cents FROM red_order_items WHERE order_id=? ORDER BY id', [id]),
    query('SELECT id, file_kind FROM stored_user_files WHERE order_id=? ORDER BY created_at', [id])
  ]);
  return { ...publicOrder(row, items, files.filter((file) => file.file_kind === 'proof'), files.filter((file) => file.file_kind === 'skin')), discordId: String(row.discord_id), username: row.username, orderKind: row.order_kind, recipientUserId: row.recipient_user_id ? Number(row.recipient_user_id) : null, reviewNote: row.review_note };
}

async function fileForOwner(orderId, fileId, userId, expectedKind) {
  const rows = await query(
    `SELECT f.id, f.object_key, f.mime_type, f.file_size, f.file_kind
     FROM stored_user_files f JOIN red_orders o ON o.id=f.order_id
     WHERE f.id=? AND f.order_id=? AND o.user_id=? LIMIT 1`, [fileId, orderId, userId]
  );
  if (!rows.length || rows[0].file_kind !== expectedKind) return null;
  return rows[0];
}

function decodeReceipt(input) {
  const buffer = decodeBase64(input, MAX_PROOF_BYTES, 'Choose a PNG, JPEG, or WebP receipt up to 3 MB.');
  const type = receiptType(buffer);
  if (!type) throw new Error('Receipt files must be PNG, JPEG, or WebP images.');
  return { buffer, type };
}

function decodeSkin(input) {
  const buffer = decodeBase64(input, MAX_SKIN_BYTES, 'Choose a ZIP file up to 10 MB.');
  return validateSkinArchive(buffer);
}

async function saveUpload({ orderId, userId, kind, input, buffer, type }) {
  const file = await storeFile({ orderId, kind, buffer, contentType: type });
  const id = uuid();
  await query(
    'INSERT INTO stored_user_files (id, order_id, user_id, file_kind, object_key, mime_type, file_size) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, orderId, userId, kind, file.objectKey, type, file.size]
  );
  return { id };
}

async function activePromo(connection, code, userId, subtotalCents) {
  const normalized = text(code, 32).toUpperCase();
  if (!normalized) return { code: null, discountCents: 0 };
  const [rows] = await connection.execute(
    'SELECT * FROM promo_codes WHERE code=? AND cancelled_at IS NULL AND expires_at > UTC_TIMESTAMP() FOR UPDATE', [normalized]
  );
  if (!rows.length) throw new Error('This promo code is not active.');
  const promo = rows[0];
  const [counts] = await connection.execute('SELECT COUNT(*) AS uses FROM promo_uses WHERE promo_id=?', [promo.id]);
  const [mine] = await connection.execute('SELECT COUNT(*) AS uses FROM promo_uses WHERE promo_id=? AND user_id=?', [promo.id, userId]);
  if ((promo.max_uses !== null && Number(counts[0].uses) >= Number(promo.max_uses)) || Number(mine[0].uses) >= Number(promo.per_user)) throw new Error('This promo code has reached its usage limit.');
  const discountCents = Math.min(subtotalCents, Math.floor(subtotalCents * Number(promo.percent_off) / 100));
  return { code: normalized, id: Number(promo.id), discountCents };
}

async function promoQuote(code, userId, subtotalCents) {
  const normalized = text(code, 32).toUpperCase();
  if (!normalized) return { cents: subtotalCents, discountCents: 0, promo: null };
  const promos = await query('SELECT * FROM promo_codes WHERE code=? AND cancelled_at IS NULL AND expires_at > UTC_TIMESTAMP() LIMIT 1', [normalized]);
  if (!promos.length) throw new Error('This promo code is not active.');
  const promo = promos[0];
  const [counts, mine] = await Promise.all([
    query('SELECT COUNT(*) AS uses FROM promo_uses WHERE promo_id=?', [promo.id]),
    query('SELECT COUNT(*) AS uses FROM promo_uses WHERE promo_id=? AND user_id=?', [promo.id, userId])
  ]);
  if ((promo.max_uses !== null && Number(counts[0].uses) >= Number(promo.max_uses)) || Number(mine[0].uses) >= Number(promo.per_user)) throw new Error('This promo code has reached its usage limit.');
  const discountCents = Math.min(subtotalCents, Math.floor(subtotalCents * Number(promo.percent_off) / 100));
  return { cents: subtotalCents - discountCents, discountCents, promo: { code: promo.code, percent: Number(promo.percent_off) } };
}

async function createOrderRecord({ userId, requestId, playerName, discordName, method, orderKind, recipientUserId, items, subtotalCents, promoCode, topupAmountCents }) {
  return withTransaction(async (connection) => {
    const [existing] = await connection.execute('SELECT * FROM red_orders WHERE user_id=? AND request_id=? LIMIT 1 FOR UPDATE', [userId, requestId]);
    if (existing.length) {
      if (existing[0].method !== method || existing[0].order_kind !== orderKind) throw new Error('This request ID was already used for a different checkout.');
      return existing[0];
    }
    const promo = orderKind === 'store' ? await activePromo(connection, promoCode, userId, subtotalCents) : { code: null, discountCents: 0 };
    const amountUsdCents = Math.max(0, subtotalCents - promo.discountCents);
    const rate = method === 'cih' ? cihRate() : null;
    if (method === 'cih' && !rate) throw new Error('CIH payment is not configured yet.');
    const currency = method === 'cih' ? 'MAD' : 'USD';
    const totalCents = method === 'cih' ? Math.round(amountUsdCents * rate) : amountUsdCents;
    const id = uuid();
    const status = method === 'cih' ? 'awaiting_review' : 'pending';
    const [insert] = await connection.execute(
      `INSERT INTO red_orders
       (id,user_id,request_id,player_name,discord_name,order_kind,recipient_user_id,method,status,fulfillment,currency,subtotal_cents,discount_cents,total_cents,promo_code,transfer_reference)
       VALUES (?,?,?,?,?,?,?,?,?,'pending',?,?,?,?,?,?)`,
      [id, userId, requestId, playerName, discordName, orderKind, recipientUserId, method, status, currency, subtotalCents, promo.discountCents, totalCents, promo.code, id.replaceAll('-', '').slice(0, 12).toUpperCase()]
    );
    for (const item of items) {
      await connection.execute(
        `INSERT INTO red_order_items (order_id,product_id,product_name,plan_id,plan_label,quantity,car_name,skin_name,weapon_name,unit_cents,total_cents)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        [id, item.id, item.name, item.planId, item.planLabel, item.qty, item.car || null, item.skin || null, item.weapon || null, item.unitCents, item.totalCents]
      );
    }
    if (promo.id) {
      await connection.execute('INSERT INTO promo_uses (promo_id,user_id,order_id) VALUES (?,?,?)', [promo.id, userId, id]);
      await connection.execute('UPDATE promo_codes SET used_count=used_count+1 WHERE id=?', [promo.id]);
    }
    if (method === 'balance') {
      const [walletRows] = await connection.execute('SELECT balance_cents FROM user_wallets WHERE user_id=? FOR UPDATE', [userId]);
      const balance = Number(walletRows[0]?.balance_cents || 0);
      if (balance < totalCents) throw new Error('Your website balance is too low.');
      await connection.execute('UPDATE user_wallets SET balance_cents=balance_cents-? WHERE user_id=?', [totalCents, userId]);
      await connection.execute('UPDATE red_orders SET status=? WHERE id=?', ['paid', id]);
      await connection.execute('INSERT INTO wallet_ledger (user_id,order_id,kind,cents,note,idempotency_key) VALUES (?,?,?,?,?,?)', [userId, id, 'purchase', -totalCents, `Order #${insert.insertId}`, `purchase:${id}`]);
    }
    const [rows] = await connection.execute('SELECT * FROM red_orders WHERE id=? LIMIT 1', [id]);
    return rows[0];
  });
}

router.get('/checkout/account', requireUser, async (req, res) => {
  const rows = await query('SELECT game_username FROM app_users WHERE id=? LIMIT 1', [req.auth.user.id]);
  const username = rows[0]?.game_username;
  if (!username) return res.status(409).json({ error: 'No game account is linked to your Discord ID yet. Contact the RED PVP team to link your MTA account.' });
  res.json({ profile: { username } });
});

router.get('/payments/config', requireUser, async (_req, res) => {
  const enabled = cihReady();
  const cih = enabled ? {
    rate: cihRate(), accountName: text(process.env.CIH_ACCOUNT_NAME, 100),
    accountNumber: text(process.env.CIH_ACCOUNT_NUMBER, 100), bankLabel: text(process.env.CIH_BANK_LABEL, 80) || 'CIH BANK'
  } : null;
  res.json({ paypalReady: paypalReady(), cihReady: enabled, balanceReady: true, cih, paypalMode: process.env.PAYPAL_ENV === 'live' ? 'live' : 'sandbox' });
});

router.post('/payments/quote', requireUser, requireCsrf, async (req, res) => {
  try {
    const items = normalizeCart(req.body?.cart);
    const subtotal = totalCartCents(items);
    const result = await promoQuote(req.body?.promo, req.auth.user.id, subtotal);
    res.json({ cents: result.cents, discountCents: result.discountCents, promo: result.promo });
  } catch (error) {
    res.status(400).json({ error: error.message || 'The quote could not be calculated.' });
  }
});

router.get('/wallet', requireUser, async (req, res) => {
  const rows = await query('SELECT balance_cents FROM user_wallets WHERE user_id=? LIMIT 1', [req.auth.user.id]);
  res.json({ balanceCents: Number(rows[0]?.balance_cents || 0) });
});

router.post('/payments/orders', requireUser, requireCsrf, async (req, res) => {
  let proof = null;
  try {
    const method = text(req.body?.method, 16);
    if (!['paypal', 'cih', 'balance'].includes(method)) return res.status(400).json({ error: 'Choose an available payment method.' });
    const requestId = text(req.body?.requestId, 36);
    if (!UUID_RE.test(requestId)) return res.status(400).json({ error: 'The checkout request is invalid. Please refresh and try again.' });
    const orderKind = req.body?.kind === 'wallet_topup' ? 'wallet_topup' : 'store';
    if (orderKind === 'wallet_topup' && method === 'balance') return res.status(400).json({ error: 'Wallet top-ups cannot be paid with wallet balance.' });
    if (method === 'paypal' && !paypalReady()) return res.status(503).json({ error: 'PayPal is not configured yet.' });
    if (method === 'cih' && !cihReady()) return res.status(503).json({ error: 'CIH bank transfer is not configured yet.' });
    if (method === 'cih') proof = decodeReceipt(req.body?.proof);

    let items;
    let subtotalCents;
    let playerName;
    let recipientUserId = null;
    if (orderKind === 'wallet_topup') {
      const amountCents = int(req.body?.amountCents, 1, 1_000_000) ?? (typeof req.body?.amount === 'string' || typeof req.body?.amount === 'number' ? Math.round(Number(req.body.amount) * 100) : null);
      if (!Number.isSafeInteger(amountCents) || amountCents < 1 || amountCents > 1_000_000) return res.status(400).json({ error: 'Top-up amount must be between $0.01 and $10,000.' });
      const recipientDiscordId = text(req.body?.recipientDiscordId || req.body?.toDiscordId || req.body?.recipientId || req.body?.recipient?.id, 22);
      if (recipientDiscordId && recipientDiscordId !== req.auth.user.discordId) {
        if (!/^\d{16,22}$/.test(recipientDiscordId)) return res.status(400).json({ error: 'The gift recipient is invalid.' });
        const recipients = await query('SELECT id FROM app_users WHERE discord_id=? LIMIT 1', [recipientDiscordId]);
        if (!recipients.length) return res.status(404).json({ error: 'The gift recipient has not signed in to RED PVP yet.' });
        recipientUserId = Number(recipients[0].id);
      } else recipientUserId = req.auth.user.id;
      items = [{ id: 'wallet-topup', name: recipientUserId === req.auth.user.id ? 'Website balance top-up' : 'Gifted website balance', planId: 'once', planLabel: 'One-time top-up', qty: 1, car: '', skin: '', weapon: '', unitCents: amountCents, totalCents: amountCents }];
      subtotalCents = amountCents;
      playerName = 'Wallet top-up';
    } else {
      items = normalizeCart(req.body?.cart);
      subtotalCents = totalCartCents(items);
      playerName = text(req.body?.player, 45);
      const linked = await query('SELECT game_username FROM app_users WHERE id=? LIMIT 1', [req.auth.user.id]);
      if (!linked[0]?.game_username) return res.status(409).json({ error: 'Link your MTA game account before placing an order.' });
      if (playerName !== linked[0].game_username) return res.status(400).json({ error: 'The selected game account does not match your linked account.' });
    }

    let order = await createOrderRecord({
      userId: req.auth.user.id, requestId, playerName, discordName: req.auth.user.username,
      method, orderKind, recipientUserId, items, subtotalCents, promoCode: req.body?.promo, topupAmountCents: orderKind === 'wallet_topup' ? subtotalCents : null
    });
    if (order.method !== method) return res.status(409).json({ error: 'This checkout request ID was already used.' });

    if (method === 'paypal' && !order.paypal_order_id) {
      const origin = req.get('origin') || process.env.REDPVP_PUBLIC_ORIGIN || '';
      let safeOrigin = '';
      try {
        const url = new URL(origin);
        const allowed = (process.env.REDPVP_ALLOWED_ORIGINS || '').split(',').map((item) => item.trim()).filter(Boolean);
        if (['https:', 'http:'].includes(url.protocol) && !url.username && !url.password && (!allowed.length || allowed.includes(url.origin))) safeOrigin = url.origin;
      } catch {}
      if (!safeOrigin) return res.status(400).json({ error: 'The checkout origin could not be verified. Refresh the page and retry.' });
      try {
        const paypal = await createPayPalOrder({
          orderId: order.id,
          totalCents: Number(order.total_cents),
          currency: order.currency,
          returnUrl: `${safeOrigin}/shop?payment_return=${encodeURIComponent(order.id)}`,
          cancelUrl: `${safeOrigin}/shop?payment_cancel=${encodeURIComponent(order.id)}`
        });
        const approvalUrl = paypal.links?.find((link) => ['approve', 'payer-action'].includes(link.rel))?.href;
        if (!paypal.id || !approvalUrl || !['CREATED', 'PAYER_ACTION_REQUIRED'].includes(paypal.status)) throw new Error('PayPal did not return an approval link.');
        await query('UPDATE red_orders SET paypal_order_id=?, paypal_approval_url=? WHERE id=? AND user_id=?', [paypal.id, approvalUrl, order.id, req.auth.user.id]);
        order = (await query('SELECT * FROM red_orders WHERE id=? LIMIT 1', [order.id]))[0];
      } catch (error) {
        console.error('PayPal order creation failed', error.providerStatus || error.message);
        return res.status(502).json({ error: 'PayPal could not start checkout. Your order was saved as pending; retry the same checkout.' });
      }
    }
    if (proof) {
      const currentFiles = await query("SELECT id FROM stored_user_files WHERE order_id=? AND file_kind='proof'", [order.id]);
      if (!currentFiles.length) await saveUpload({ orderId: order.id, userId: req.auth.user.id, kind: 'proof', input: req.body.proof, buffer: proof.buffer, type: proof.type });
    }
    const resultOrder = await orderForUser(order.id, req.auth.user.id);
    const bank = method === 'cih' ? { name: text(process.env.CIH_ACCOUNT_NAME, 100), account: text(process.env.CIH_ACCOUNT_NUMBER, 100), bank: text(process.env.CIH_BANK_LABEL, 80) || 'CIH BANK' } : undefined;
    res.status(201).json({ order: resultOrder, bank, approvalUrl: resultOrder?.approvalUrl });
  } catch (error) {
    const status = error.message?.includes('balance is too low') ? 409 : 400;
    res.status(status).json({ error: error.message || 'The order could not be created.' });
  }
});

router.post('/payments/capture', requireUser, requireCsrf, async (req, res) => {
  try {
    const orderId = text(req.body?.id, 36);
    const orders = await query('SELECT * FROM red_orders WHERE id=? AND user_id=? LIMIT 1', [orderId, req.auth.user.id]);
    if (!orders.length) return res.status(404).json({ error: 'Order not found.' });
    let row = orders[0];
    if (row.status !== 'paid') {
      if (row.method !== 'paypal' || !row.paypal_order_id) return res.status(409).json({ error: 'This order is not awaiting PayPal capture.' });
      const captured = await capturePayPalOrder({ paypalOrderId: row.paypal_order_id, orderId: row.id });
      const unit = captured.purchase_units?.[0];
      const payment = unit?.payments?.captures?.[0];
      const customId = unit?.custom_id || unit?.reference_id;
      if (captured.status !== 'COMPLETED' || payment?.status !== 'COMPLETED' || (customId !== row.id) || payment.amount?.currency_code !== row.currency || Math.round(Number(payment.amount?.value) * 100) !== Number(row.total_cents)) {
        return res.status(409).json({ error: 'PayPal has not confirmed the exact order amount yet. Check again in a moment.' });
      }
      await withTransaction(async (connection) => {
        const [locked] = await connection.execute('SELECT status FROM red_orders WHERE id=? AND user_id=? FOR UPDATE', [row.id, req.auth.user.id]);
        if (locked[0]?.status !== 'paid') {
          await connection.execute('UPDATE red_orders SET status=?, paypal_capture_id=? WHERE id=?', ['paid', payment.id || null, row.id]);
        }
      });
      row = (await query('SELECT * FROM red_orders WHERE id=? LIMIT 1', [row.id]))[0];
    }
    res.json({ order: await orderForUser(row.id, req.auth.user.id) });
  } catch (error) {
    console.error('PayPal capture failed', error.providerStatus || error.message);
    res.status(502).json({ error: error.message || 'PayPal verification is temporarily unavailable.' });
  }
});

router.post('/payments/proof', requireUser, requireCsrf, async (req, res) => {
  try {
    const orderId = text(req.body?.id, 36);
    const orders = await query('SELECT id, status, fulfillment FROM red_orders WHERE id=? AND user_id=? LIMIT 1', [orderId, req.auth.user.id]);
    if (!orders.length) return res.status(404).json({ error: 'Order not found.' });
    if (['rejected', 'fulfilled'].includes(orders[0].fulfillment)) return res.status(409).json({ error: 'This order is closed and no longer accepts receipts.' });
    const existing = await query("SELECT id FROM stored_user_files WHERE order_id=? AND file_kind='proof'", [orderId]);
    if (existing.length >= 5) return res.status(409).json({ error: 'This order already has the maximum number of receipts.' });
    const receipt = decodeReceipt(req.body?.data);
    await saveUpload({ orderId, userId: req.auth.user.id, kind: 'proof', input: req.body.data, buffer: receipt.buffer, type: receipt.type });
    res.json({ order: await orderForUser(orderId, req.auth.user.id) });
  } catch (error) {
    res.status(400).json({ error: error.message || 'The receipt could not be uploaded.' });
  }
});

router.post('/payments/skin', requireUser, requireCsrf, async (req, res) => {
  try {
    const orderId = text(req.body?.id, 36);
    const orders = await query('SELECT id, method, status, fulfillment FROM red_orders WHERE id=? AND user_id=? LIMIT 1', [orderId, req.auth.user.id]);
    if (!orders.length) return res.status(404).json({ error: 'Order not found.' });
    const order = orders[0];
    if (order.fulfillment !== 'pending' || (order.method === 'paypal' && order.status !== 'paid')) return res.status(409).json({ error: 'This order is not ready for a custom skin upload.' });
    const [requiredRows, existing] = await Promise.all([
      query("SELECT COALESCE(SUM(quantity),0) AS required_count FROM red_order_items WHERE order_id=? AND product_id='custom-skin'", [orderId]),
      query("SELECT id FROM stored_user_files WHERE order_id=? AND file_kind='skin'", [orderId])
    ]);
    const required = Number(requiredRows[0]?.required_count || 0);
    if (!required) return res.status(400).json({ error: 'This order does not include a custom skin.' });
    if (existing.length >= required) return res.status(409).json({ error: 'The required number of skin ZIP files has already been uploaded.' });
    const buffer = decodeSkin(req.body?.data);
    await saveUpload({ orderId, userId: req.auth.user.id, kind: 'skin', input: req.body.data, buffer, type: 'application/zip' });
    res.json({ order: await orderForUser(orderId, req.auth.user.id) });
  } catch (error) {
    res.status(400).json({ error: error.message || 'The skin file could not be uploaded.' });
  }
});

async function sendPrivateFile(req, res, expectedKind, download) {
  const orderId = text(req.params.orderId, 36);
  const fileId = text(req.params.fileId, 36);
  let file = null;
  if (req.auth?.user) file = await fileForOwner(orderId, fileId, req.auth.user.id, expectedKind);
  if (!file && ['staff', 'admin'].includes(req.auth?.user?.role)) {
    const rows = fileId === 'latest'
      ? await query('SELECT id, object_key, mime_type, file_size, file_kind FROM stored_user_files WHERE order_id=? AND file_kind=? ORDER BY created_at DESC LIMIT 1', [orderId, expectedKind])
      : await query('SELECT id, object_key, mime_type, file_size, file_kind FROM stored_user_files WHERE id=? AND order_id=? LIMIT 1', [fileId, orderId]);
    if (rows.length && rows[0].file_kind === expectedKind) file = rows[0];
  }
  if (!file) return res.status(404).send('File not found.');
  const stored = await readStoredFile(file.object_key);
  res.set('Content-Type', file.mime_type);
  res.set('Content-Length', String(file.file_size));
  res.set('Cache-Control', 'private, no-store');
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Content-Disposition', `${download ? 'attachment' : 'inline'}; filename="${expectedKind === 'skin' ? 'custom-skin.zip' : (file.mime_type === 'image/png' ? 'receipt.png' : file.mime_type === 'image/webp' ? 'receipt.webp' : 'receipt.jpg')}"`);
  Readable.fromWeb(stored.body).pipe(res);
}

router.get('/payments/proof/:orderId/:fileId', requireUser, async (req, res) => sendPrivateFile(req, res, 'proof', false));
router.get('/payments/skin/:orderId/:fileId', requireUser, async (req, res) => sendPrivateFile(req, res, 'skin', true));

router.get('/admin/payments/orders', requireStaff, async (req, res) => {
  const status = text(req.query.status, 24);
  const params = [];
  let where = '';
  if (status) { where = 'WHERE o.status=?'; params.push(status); }
  const orders = await query(
    `SELECT o.id, o.order_number, o.order_kind, o.method, o.status, o.fulfillment, o.currency, o.total_cents, o.created_at, u.discord_id, u.username,
      (SELECT COUNT(*) FROM stored_user_files f WHERE f.order_id=o.id AND f.file_kind='proof') AS proof_count
     FROM red_orders o JOIN app_users u ON u.id=o.user_id ${where} ORDER BY o.created_at DESC LIMIT 200`, params
  );
  res.json({ orders: orders.map((row) => ({ id: row.id, orderNumber: Number(row.order_number), orderKind: row.order_kind, method: row.method, status: row.status, fulfillment: row.fulfillment, currency: row.currency, total: money(row.total_cents), createdAt: row.created_at, discordId: String(row.discord_id), username: row.username, proofCount: Number(row.proof_count) })) });
});

router.post('/admin/payments/review', requireStaff, requireCsrf, async (req, res) => {
  const orderId = text(req.body?.id, 36);
  const decision = text(req.body?.decision, 24);
  if (!UUID_RE.test(orderId) || !['approve', 'reject', 'fulfill'].includes(decision)) return res.status(400).json({ error: 'The order review is invalid.' });
  const result = await withTransaction(async (connection) => {
    const [orders] = await connection.execute('SELECT * FROM red_orders WHERE id=? FOR UPDATE', [orderId]);
    if (!orders.length) throw Object.assign(new Error('Order not found.'), { status: 404 });
    const order = orders[0];
    if (decision === 'approve') {
      if (order.status === 'rejected' || order.fulfillment === 'fulfilled') throw Object.assign(new Error('This order can no longer be approved.'), { status: 409 });
      if (order.method === 'cih') {
        const [proofs] = await connection.execute("SELECT COUNT(*) AS count FROM stored_user_files WHERE order_id=? AND file_kind='proof'", [orderId]);
        if (Number(proofs[0].count) === 0) throw Object.assign(new Error('Upload and review a transfer receipt before approval.'), { status: 409 });
        await connection.execute('UPDATE red_orders SET status=?, review_note=? WHERE id=?', ['paid', text(req.body?.note, 500) || null, orderId]);
      }
      if (order.order_kind === 'wallet_topup') {
        if (order.status !== 'paid' && order.method !== 'cih') throw Object.assign(new Error('Payment must be verified before releasing wallet funds.'), { status: 409 });
        const recipientId = Number(order.recipient_user_id || order.user_id);
        const amount = Number(order.subtotal_cents) - Number(order.discount_cents);
        const key = `topup:${orderId}`;
        const [prior] = await connection.execute('SELECT id FROM wallet_ledger WHERE user_id=? AND idempotency_key=? LIMIT 1', [recipientId, key]);
        if (!prior.length) {
          await connection.execute('INSERT IGNORE INTO user_wallets (user_id,balance_cents) VALUES (?,0)', [recipientId]);
          await connection.execute('UPDATE user_wallets SET balance_cents=balance_cents+? WHERE user_id=?', [amount, recipientId]);
          await connection.execute('INSERT INTO wallet_ledger (user_id,order_id,kind,cents,note,idempotency_key) VALUES (?,?,?,?,?,?)', [recipientId, orderId, 'topup', amount, `Approved top-up #${order.order_number}`, key]);
        }
        await connection.execute('UPDATE red_orders SET fulfillment=? WHERE id=?', ['fulfilled', orderId]);
      }
    } else if (decision === 'reject') {
      if (order.status === 'rejected' || order.fulfillment === 'fulfilled') throw Object.assign(new Error('This order can no longer be rejected.'), { status: 409 });
      const note = text(req.body?.note, 500) || 'The payment or fulfillment was rejected by staff.';
      await connection.execute('UPDATE red_orders SET status=?, fulfillment=?, review_note=? WHERE id=?', ['rejected', 'rejected', note, orderId]);
      if (order.method === 'balance') {
        const key = `refund:${orderId}`;
        const [prior] = await connection.execute('SELECT id FROM wallet_ledger WHERE user_id=? AND idempotency_key=? LIMIT 1', [order.user_id, key]);
        if (!prior.length) {
          await connection.execute('UPDATE user_wallets SET balance_cents=balance_cents+? WHERE user_id=?', [order.total_cents, order.user_id]);
          await connection.execute('INSERT INTO wallet_ledger (user_id,order_id,kind,cents,note,idempotency_key) VALUES (?,?,?,?,?,?)', [order.user_id, orderId, 'refund', order.total_cents, `Refund for order #${order.order_number}`, key]);
        }
      }
    } else {
      if (order.status !== 'paid' || order.fulfillment !== 'pending' || order.order_kind !== 'store') throw Object.assign(new Error('Only paid store orders awaiting delivery can be fulfilled.'), { status: 409 });
      await connection.execute('UPDATE red_orders SET fulfillment=?, review_note=? WHERE id=?', ['fulfilled', text(req.body?.note, 500) || null, orderId]);
    }
    return { ok: true };
  });
  res.json(result);
});

export default router;
