import { Router } from 'express';
import { query } from '../db/index.js';
import { requireCsrf, requireUser } from '../middleware/auth.js';
import { turnstileReady, verifyTurnstile } from '../services/turnstile.js';
import { hashIp } from '../uploads/validation.js';
import { int, text } from '../utils.js';
import { callMtaApi, futureExpiry, getMtaStatus } from '../services/mta.js';

const router = Router();
const IPV4 = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

function clientIp(req) {
  let value = String(req.ip || req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  if (value.startsWith('::1')) value = '127.0.0.1';
  return value;
}

function shieldAvailable() {
  return Boolean(process.env.MTA_SHIELD_VERIFY_URL && process.env.MTA_API_TOKEN && turnstileReady());
}

router.get('/server-status', async (_req, res) => res.json(await getMtaStatus()));

router.get('/shield/status', requireUser, async (req, res) => {
  const ip = clientIp(req);
  const supported = IPV4.test(ip);
  const record = supported ? await query('SELECT status, expires_at FROM shield_verifications WHERE user_id=? AND ip_hash=? LIMIT 1', [req.auth.user.id, hashIp(ip)]) : [];
  const expiryTime = record[0]?.expires_at ? new Date(record[0].expires_at).getTime() : NaN;
  const active = Boolean(record[0]?.status === 'active' && Number.isFinite(expiryTime) && expiryTime > Date.now());
  const expiresAt = Number.isFinite(expiryTime) ? new Date(expiryTime).toISOString() : null;
  const status = active ? 'active' : record[0]?.status === 'active' ? 'expired' : (record[0]?.status || 'not_verified');
  res.json({ ip, isIpv4: supported, supported, ready: shieldAvailable(), configured: shieldAvailable(), siteKey: process.env.TURNSTILE_SITE_KEY || '', allowed: active, active, status, expiresAt, canRenew: active && shieldAvailable(), renewAfter: expiresAt });
});

router.post('/shield/verify', requireUser, requireCsrf, async (req, res) => {
  if (!shieldAvailable()) return res.status(503).json({ error: 'MTA Shield integration is not configured. Contact the RED PVP team.' });
  const ip = clientIp(req);
  if (!IPV4.test(ip)) return res.status(400).json({ error: 'Shield verification currently supports IPv4 only.' });
  const token = text(req.body?.captchaToken || req.body?.token || req.body?.turnstileToken || req.body?.['cf-turnstile-response'], 2048);
  if (!token || !await verifyTurnstile(token, ip)) return res.status(403).json({ error: 'Cloudflare verification failed. Please try again.' });
  try {
    const result = await callMtaApi(process.env.MTA_SHIELD_VERIFY_URL, { action: 'verify', discordId: req.auth.user.discordId, ip });
    if (result.allowed !== true) return res.status(403).json({ error: 'The MTA server did not approve this IP.' });
    const expiresAt = futureExpiry(result.expiresAt);
    if (!expiresAt) return res.status(502).json({ error: 'The MTA integration returned an invalid or expired Shield expiry.' });
    await query(
      `INSERT INTO shield_verifications (user_id,ip_hash,status,expires_at,external_reference)
       VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status), expires_at=VALUES(expires_at), external_reference=VALUES(external_reference)`,
      [req.auth.user.id, hashIp(ip), 'active', expiresAt, text(result.reference, 128) || null]
    );
    res.json({ ok: true, allowed: true, expiresAt });
  } catch (error) {
    res.status(502).json({ error: error.message || 'MTA Shield verification is unavailable.' });
  }
});

router.post('/shield/renew', requireUser, requireCsrf, async (req, res) => {
  if (!shieldAvailable()) return res.status(503).json({ error: 'MTA Shield integration is not configured.' });
  const ip = clientIp(req);
  if (!IPV4.test(ip)) return res.status(400).json({ error: 'Shield renewal currently supports IPv4 only.' });
  const records = await query('SELECT status, expires_at FROM shield_verifications WHERE user_id=? AND ip_hash=? LIMIT 1', [req.auth.user.id, hashIp(ip)]);
  if (records[0]?.status !== 'active' || !records[0]?.expires_at || new Date(records[0].expires_at).getTime() <= Date.now()) return res.status(409).json({ error: 'There is no active, unexpired Shield verification to renew.' });
  try {
    const result = await callMtaApi(process.env.MTA_SHIELD_VERIFY_URL, { action: 'renew', discordId: req.auth.user.discordId, ip });
    if (result.allowed !== true) return res.status(403).json({ error: 'The MTA server did not approve this renewal.' });
    const expiresAt = futureExpiry(result.expiresAt);
    if (!expiresAt) return res.status(502).json({ error: 'The MTA integration returned an invalid or expired Shield expiry.' });
    await query('UPDATE shield_verifications SET expires_at=?, external_reference=? WHERE user_id=? AND ip_hash=?', [expiresAt, text(result.reference, 128) || null, req.auth.user.id, hashIp(ip)]);
    res.json({ ok: true, allowed: true, expiresAt });
  } catch (error) {
    res.status(502).json({ error: error.message || 'MTA Shield renewal is unavailable.' });
  }
});

router.post('/shield/revoke', requireUser, requireCsrf, async (req, res) => {
  if (!process.env.MTA_SHIELD_REVOKE_URL || !process.env.MTA_API_TOKEN) return res.status(503).json({ error: 'MTA Shield revocation is not configured.' });
  const ip = clientIp(req);
  if (!IPV4.test(ip)) return res.status(400).json({ error: 'Shield revocation currently supports IPv4 only.' });
  try {
    const result = await callMtaApi(process.env.MTA_SHIELD_REVOKE_URL, { action: 'revoke', discordId: req.auth.user.discordId, ip });
    if (result.revoked !== true) return res.status(409).json({ error: 'The MTA server did not confirm revocation.' });
    await query('UPDATE shield_verifications SET status=? WHERE user_id=? AND ip_hash=?', ['revoked', req.auth.user.id, hashIp(ip)]);
    res.json({ ok: true, revoked: true });
  } catch (error) {
    res.status(502).json({ error: error.message || 'MTA Shield revocation is unavailable.' });
  }
});

export default router;
