import { Router } from 'express';
import { query, withTransaction } from '../db/index.js';
import { requireCsrf, requireUser } from '../middleware/auth.js';
import { clientOrigin, jsonValue, text } from '../utils.js';
import { appendCookie, beginOAuthCookie, clearOAuthCookie, clearCookie, createOAuthState, createSession, hashOAuthState, readOAuthCookie, revokeSession } from '../services/sessions.js';

const router = Router();
const DISCORD_API = 'https://discord.com/api/v10';

function safeReturnTo(value) {
  const route = text(value, 255);
  return route.startsWith('/') && !route.startsWith('//') && !/[\\\u0000-\u001f]/.test(route) ? route : '/dashboard';
}

function redirectUri(origin) {
  if (process.env.DISCORD_REDIRECT_URI) return process.env.DISCORD_REDIRECT_URI;
  return `${origin}/auth/discord/callback`;
}

function validCallback(origin, callback) {
  try {
    const url = new URL(callback);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return false;
    if (process.env.DISCORD_REDIRECT_URI) return url.href === new URL(process.env.DISCORD_REDIRECT_URI).href;
    return url.origin === origin && url.pathname === '/auth/discord/callback';
  } catch { return false; }
}

router.get('/discord', async (req, res) => {
  const clientId = process.env.DISCORD_CLIENT_ID;
  const clientSecret = process.env.DISCORD_CLIENT_SECRET;
  const origin = clientOrigin(req);
  if (!clientId || !clientSecret || !origin) return res.status(503).send('Discord sign-in is not configured for this site yet.');
  const state = createOAuthState();
  const returnTo = safeReturnTo(req.query.return_to);
  const callback = redirectUri(origin);
  if (!validCallback(origin, callback)) return res.status(400).send('Discord callback configuration is invalid.');
  await query('DELETE FROM oauth_states WHERE expires_at < UTC_TIMESTAMP()');
  await query('INSERT INTO oauth_states (state_hash, return_to, origin, expires_at) VALUES (?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 10 MINUTE))', [hashOAuthState(state), returnTo, origin]);
  beginOAuthCookie(res, state);
  const auth = new URL(`${DISCORD_API}/oauth2/authorize`);
  auth.searchParams.set('client_id', clientId);
  auth.searchParams.set('redirect_uri', callback);
  auth.searchParams.set('response_type', 'code');
  auth.searchParams.set('scope', 'identify');
  auth.searchParams.set('state', state);
  res.redirect(302, auth.toString());
});

router.get('/discord/callback', async (req, res) => {
  const state = text(req.query.state, 128);
  const code = text(req.query.code, 2048);
  const stateCookie = readOAuthCookie(req.headers.cookie);
  clearOAuthCookie(res);
  if (!state || !code || !stateCookie || state !== stateCookie) return res.status(400).send('Discord sign-in expired. Return to the site and try again.');
  const states = await query('SELECT return_to, origin FROM oauth_states WHERE state_hash=? AND expires_at > UTC_TIMESTAMP() LIMIT 1', [hashOAuthState(state)]);
  await query('DELETE FROM oauth_states WHERE state_hash=?', [hashOAuthState(state)]);
  if (!states.length) return res.status(400).send('Discord sign-in could not be verified. Try again.');
  const { return_to: returnTo, origin } = states[0];
  const clientId = process.env.DISCORD_CLIENT_ID;
  const clientSecret = process.env.DISCORD_CLIENT_SECRET;
  const callback = redirectUri(origin);
  if (!clientId || !clientSecret || !validCallback(origin, callback)) return res.status(503).send('Discord sign-in is not configured yet.');

  const tokenResponse = await fetch(`${DISCORD_API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, grant_type: 'authorization_code', code, redirect_uri: callback }),
    signal: AbortSignal.timeout(15_000)
  });
  const tokenData = await tokenResponse.json().catch(() => ({}));
  if (!tokenResponse.ok || typeof tokenData.access_token !== 'string') return res.status(401).send('Discord could not complete sign-in. Please retry.');

  const profileResponse = await fetch(`${DISCORD_API}/users/@me`, {
    headers: { Authorization: `Bearer ${tokenData.access_token}` },
    signal: AbortSignal.timeout(15_000)
  });
  const profile = await profileResponse.json().catch(() => ({}));
  if (!profileResponse.ok || !/^\d{16,22}$/.test(String(profile.id || '')) || typeof profile.username !== 'string') return res.status(401).send('Discord profile could not be verified.');
  const avatar = typeof profile.avatar === 'string' ? `https://cdn.discordapp.com/avatars/${profile.id}/${profile.avatar}.png?size=128` : '/assets/red-pvp-logo.png';
  const admins = new Set((process.env.REDPVP_ADMIN_DISCORD_IDS || '').split(',').map((id) => id.trim()).filter(Boolean));
  const user = await withTransaction(async (connection) => {
    const role = admins.has(String(profile.id)) ? 'admin' : 'player';
    await connection.execute(
      `INSERT INTO app_users (discord_id, username, avatar_url, role)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE username=VALUES(username), avatar_url=VALUES(avatar_url), role=IF(VALUES(role)='admin','admin',role)`,
      [String(profile.id), text(profile.global_name || profile.username, 80), avatar, role]
    );
    const [rows] = await connection.execute('SELECT id, username, role FROM app_users WHERE discord_id=? LIMIT 1', [String(profile.id)]);
    await connection.execute('INSERT IGNORE INTO user_wallets (user_id, balance_cents) VALUES (?, 0)', [rows[0].id]);
    return rows[0];
  });
  await createSession(user.id, res);
  res.redirect(303, `${origin}${safeReturnTo(returnTo)}`);
});

router.get('/session', async (req, res) => {
  const user = req.auth?.user || null;
  res.set('Cache-Control', 'no-store');
  res.json({ user, csrfToken: req.auth?.csrfToken || null, dashboardAvailable: Boolean(user) });
});

router.post('/logout', requireUser, requireCsrf, async (req, res) => {
  await revokeSession(req.auth.sessionHash);
  clearCookie(res, 'redpvp_session', { maxAge: 0 });
  res.json({ ok: true });
});

router.get('/my-ranking', requireUser, async (req, res) => {
  const rows = await query(
    `SELECT r.playtime_hours, r.score, r.rank_label,
      (SELECT COUNT(*) + 1 FROM game_rankings x WHERE x.score > r.score) AS position
     FROM game_rankings r WHERE r.user_id=? LIMIT 1`, [req.auth.user.id]
  );
  if (!rows.length) return res.json({ ranking: null });
  res.json({ ranking: { hours: Number(rows[0].playtime_hours), score: Number(rows[0].score), rank: rows[0].rank_label, position: Number(rows[0].position) } });
});

router.get('/orders', requireUser, async (req, res) => {
  const orders = await query(
    `SELECT id, order_number, method, status, fulfillment, currency, total_cents, transfer_reference, created_at
     FROM red_orders WHERE user_id=? ORDER BY created_at DESC LIMIT 50`, [req.auth.user.id]
  );
  const ids = orders.map((order) => order.id);
  let items = [];
  if (ids.length) {
    const placeholders = ids.map(() => '?').join(',');
    items = await query(`SELECT order_id, product_id AS id, product_name AS name, plan_id AS planId, plan_label AS duration, quantity AS qty, car_name AS car, skin_name AS skin, weapon_name AS weapon, unit_cents, total_cents FROM red_order_items WHERE order_id IN (${placeholders}) ORDER BY id`, ids);
  }
  const files = ids.length ? await query(`SELECT id, order_id, file_kind, object_key FROM stored_user_files WHERE order_id IN (${ids.map(() => '?').join(',')}) ORDER BY created_at`, ids) : [];
  const grouped = new Map();
  for (const file of files) {
    const collection = grouped.get(file.order_id) || { proofs: [], skinFiles: [] };
    const entry = { id: file.id };
    collection[file.file_kind === 'proof' ? 'proofs' : 'skinFiles'].push(entry);
    grouped.set(file.order_id, collection);
  }
  const byOrder = new Map();
  for (const item of items) {
    const group = byOrder.get(item.order_id) || [];
    group.push(item);
    byOrder.set(item.order_id, group);
  }
  res.json({ orders: orders.map((order) => ({
    id: order.id, orderNumber: Number(order.order_number), method: order.method, status: order.status,
    fulfillment: order.fulfillment, currency: order.currency, total: (Number(order.total_cents) / 100).toFixed(2),
    transferReference: order.transfer_reference, createdAt: order.created_at,
    items: byOrder.get(order.id) || [], ...(grouped.get(order.id) || { proofs: [], skinFiles: [] })
  })) });
});

export default router;
