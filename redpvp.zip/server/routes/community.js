import { createHash } from 'node:crypto';
import { Router } from 'express';
import { query, withTransaction } from '../db/index.js';
import { requireAdmin, requireCsrf, requireStaff, requireUser } from '../middleware/auth.js';
import { int, jsonValue, text } from '../utils.js';
import { getMtaStatus } from '../services/mta.js';

const router = Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const routeError = (message, status = 400) => Object.assign(new Error(message), { status });
const parseJson = (value, fallback) => jsonValue(value, fallback);
const publicUser = (row) => ({ id: String(row.discord_id), discordId: String(row.discord_id), username: row.username, name: row.username, avatar: row.avatar_url || '/assets/red-pvp-logo.png', role: row.role });


async function notifyRequest(id) {
  const rows = await query(
    `SELECT r.id, r.request_type, r.status, u.discord_id, u.username
     FROM community_requests r JOIN app_users u ON u.id=r.user_id WHERE r.id=? LIMIT 1`, [id]
  );
  if (!rows.length) return { status: 'failed', error: 'Request not found.' };
  const row = rows[0];
  if (!['approved', 'rejected'].includes(row.status)) return { status: 'failed', error: 'Review the request before sending a notification.' };
  if (!process.env.DISCORD_BOT_TOKEN) {
    await query("UPDATE community_requests SET notification_status='failed' WHERE id=?", [id]);
    return { status: 'failed', error: 'Discord bot notifications are not configured.' };
  }
  const claimed = await query("UPDATE community_requests SET notification_status='sending' WHERE id=? AND notification_status<>'sent'", [id]);
  if (!claimed.affectedRows) return { status: 'sent', alreadySent: true };
  try {
    const headers = { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}`, 'Content-Type': 'application/json' };
    const dmResponse = await fetch('https://discord.com/api/v10/users/@me/channels', {
      method: 'POST', headers, body: JSON.stringify({ recipient_id: String(row.discord_id) }), signal: AbortSignal.timeout(12_000)
    });
    const channel = await dmResponse.json().catch(() => ({}));
    if (!dmResponse.ok || !/^\d{16,22}$/.test(String(channel.id || ''))) throw new Error('Discord DM could not be opened.');
    const label = row.request_type === 'whitelist' ? 'whitelist application' : 'community application';
    const message = `RED PVP update: Your ${label} has been ${row.status}. Sign in to the RED PVP dashboard to review your request.`;
    const messageResponse = await fetch(`https://discord.com/api/v10/channels/${channel.id}/messages`, {
      method: 'POST', headers, body: JSON.stringify({ content: message }), signal: AbortSignal.timeout(12_000)
    });
    if (!messageResponse.ok) throw new Error('Discord DM could not be delivered.');
    await query("UPDATE community_requests SET notification_status='sent' WHERE id=?", [id]);
    return { status: 'sent' };
  } catch {
    await query("UPDATE community_requests SET notification_status='failed' WHERE id=?", [id]);
    return { status: 'failed', error: 'Discord DM delivery failed. Retry after checking the bot and recipient privacy settings.' };
  }
}

router.get('/dashboard', requireUser, async (req, res) => {
  const staffView = ['staff', 'admin'].includes(req.auth.user.role);
  const requests = staffView
    ? await query(`SELECT r.*, u.discord_id, u.username, u.avatar_url FROM community_requests r JOIN app_users u ON u.id=r.user_id ORDER BY r.created_at DESC LIMIT 250`)
    : await query(`SELECT r.*, u.discord_id, u.username, u.avatar_url FROM community_requests r JOIN app_users u ON u.id=r.user_id WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 50`, [req.auth.user.id]);
  const formatted = requests.map((row) => {
    const payload = parseJson(row.payload, {});
    return {
      ...payload,
      id: Number(row.id), userId: String(row.discord_id), username: row.username, avatar: row.avatar_url || '/assets/red-pvp-logo.png',
      type: row.request_type, status: row.status, created: row.created_at, payload,
      notification: { status: row.notification_status }, reviewAttempt: parseJson(row.review_attempt, null), effectError: row.effect_error || null,
      effects: payload.effects || {}, discordSync: payload.discordSync || null
    };
  });
  const server = await getMtaStatus();
  res.json({
    user: req.auth.user,
    requests: formatted,
    server,
    account: { linked: Boolean(req.auth.user.gameUsername), gameName: req.auth.user.gameUsername || null }
  });
});

router.get('/rules', async (_req, res) => {
  const rows = await query('SELECT body_text, categories, updated_at FROM site_rules WHERE rule_key=? LIMIT 1', ['main']);
  const row = rows[0];
  res.json({ text: row?.body_text || '', categories: parseJson(row?.categories, []), updatedAt: row?.updated_at || null });
});

router.post('/requests', requireUser, requireCsrf, async (req, res) => {
  const type = text(req.body?.type, 32);
  if (type !== 'whitelist') return res.status(400).json({ error: 'This request type is not available.' });
  const inviter = text(req.body?.inviter, 45);
  const code = text(req.body?.code, 20).toUpperCase();
  if (!inviter || !/^RED-[A-Z0-9]{4,16}$/.test(code)) return res.status(400).json({ error: 'Enter a valid inviter and whitelist code.' });
  const existing = await query("SELECT id FROM community_requests WHERE user_id=? AND request_type='whitelist' AND status='pending' LIMIT 1", [req.auth.user.id]);
  if (existing.length) return res.status(409).json({ error: 'You already have a whitelist request awaiting review.' });
  await query('INSERT INTO community_requests (user_id, request_type, payload, status) VALUES (?, ?, ?, ?)', [req.auth.user.id, type, JSON.stringify({ inviter, code }), 'pending']);
  res.status(201).json({ ok: true });
});

router.get('/wallet', requireUser, async (req, res) => {
  const [walletRows, ledger] = await Promise.all([
    query('SELECT balance_cents FROM user_wallets WHERE user_id=? LIMIT 1', [req.auth.user.id]),
    query('SELECT kind, cents, note, created_at FROM wallet_ledger WHERE user_id=? ORDER BY created_at DESC LIMIT 100', [req.auth.user.id])
  ]);
  res.json({ balanceCents: Number(walletRows[0]?.balance_cents || 0), ledger: ledger.map((row) => ({ kind: row.kind, cents: Number(row.cents), note: row.note, at: row.created_at })) });
});

router.post('/wallet/recipient', requireUser, requireCsrf, async (req, res) => {
  const discordId = text(req.body?.discordId, 22);
  if (!/^\d{16,22}$/.test(discordId)) return res.status(400).json({ error: 'Enter a valid Discord ID.' });
  const rows = await query('SELECT discord_id, username, avatar_url FROM app_users WHERE discord_id=? LIMIT 1', [discordId]);
  if (!rows.length) return res.status(404).json({ error: 'This Discord account has not signed in to RED PVP yet.' });
  res.json({ member: publicUser({ ...rows[0], role: 'player' }) });
});

router.get('/admin/staff', requireStaff, async (_req, res) => {
  const rows = await query(
    `SELECT u.discord_id, u.username, u.avatar_url, u.role, s.game_name, s.serial_hash, s.role_names, s.discord_roles
     FROM app_users u LEFT JOIN staff_profiles s ON s.user_id=u.id
     WHERE u.role IN ('staff','admin') ORDER BY u.role, u.username`
  );
  res.json({ staff: rows.map((row) => ({
    id: String(row.discord_id), name: row.username, discordUsername: row.username, avatar: row.avatar_url,
    serial: row.serial_hash ? 'Stored securely' : '', gameName: row.game_name || '', role: row.role,
    roleNames: parseJson(row.role_names, [row.role]), discordRoles: parseJson(row.discord_roles, [])
  })) });
});

router.get('/admin/clans', requireStaff, async (_req, res) => {
  const rows = await query(
    `SELECT c.id, c.name, c.tag, c.description, c.avatar_url, c.guild_id, c.chat_channel_id, c.voice_channel_id, c.status, c.leader_user_id,
      u.discord_id AS leader_id, u.username AS leader_name, u.avatar_url AS leader_avatar,
      (SELECT COUNT(*) FROM clan_members cm WHERE cm.clan_id=c.id) AS member_count,
      (SELECT GROUP_CONCAT(u2.discord_id ORDER BY u2.username SEPARATOR ',') FROM clan_members cm2 JOIN app_users u2 ON u2.id=cm2.user_id WHERE cm2.clan_id=c.id) AS member_ids
     FROM clans c LEFT JOIN app_users u ON u.id=c.leader_user_id ORDER BY c.name`
  );
  res.json({ clans: rows.map((row) => ({
    id: Number(row.id), name: row.name, tag: row.tag, description: row.description, status: row.status,
    avatarUrl: row.avatar_url || null, guild_id: row.guild_id || '', chat_channel_id: row.chat_channel_id || '', voice_channel_id: row.voice_channel_id || '',
    leader_id: row.leader_id || '', leader: row.leader_id ? { id: String(row.leader_id), name: row.leader_name, username: row.leader_name, avatar: row.leader_avatar } : null,
    memberCount: Number(row.member_count), memberIds: String(row.member_ids || '').split(',').filter(Boolean)
  })) });
});

router.get('/admin/clans/:id', requireStaff, async (req, res) => {
  const id = int(req.params.id, 1, Number.MAX_SAFE_INTEGER);
  if (!id) return res.status(400).json({ error: 'Invalid clan ID.' });
  const [clans, members, history] = await Promise.all([
    query('SELECT c.*, u.discord_id AS leader_id, u.username AS leader_name, u.avatar_url AS leader_avatar FROM clans c LEFT JOIN app_users u ON u.id=c.leader_user_id WHERE c.id=? LIMIT 1', [id]),
    query(`SELECT u.discord_id, u.username, u.avatar_url, u.game_username, cm.role AS member_role,
             (c.leader_user_id=u.id) AS is_leader
           FROM clan_members cm JOIN app_users u ON u.id=cm.user_id JOIN clans c ON c.id=cm.clan_id
           WHERE cm.clan_id=? ORDER BY is_leader DESC, u.username`, [id]),
    query('SELECT action_type, actor_discord_id, actor_name, input_json, state, created_at FROM clan_management_operations WHERE clan_id=? ORDER BY created_at DESC LIMIT 100', [id])
  ]);
  if (!clans.length) return res.status(404).json({ error: 'Clan not found.' });
  const row = clans[0];
  res.json({ clan: {
    id: Number(row.id), name: row.name, tag: row.tag, description: row.description, status: row.status, avatarUrl: row.avatar_url || null,
    guild_id: row.guild_id || '', chat_channel_id: row.chat_channel_id || '', voice_channel_id: row.voice_channel_id || '',
    leader_id: row.leader_id || '', leader: row.leader_id ? { id: String(row.leader_id), name: row.leader_name, username: row.leader_name, avatar: row.leader_avatar } : null,
    members: members.map((member) => ({
      discord_id: String(member.discord_id), role: Number(member.is_leader) ? 'leader' : member.member_role,
      profile: {
        id: String(member.discord_id), name: member.username, username: member.username, discord_username: member.username,
        avatar: member.avatar_url || '/assets/red-pvp-logo.png', avatar_url: member.avatar_url || '/assets/red-pvp-logo.png',
        account: member.game_username ? { id: member.game_username, username: member.game_username, mtanick: member.game_username } : null
      }
    }))
  }, operations: history.map((op) => ({
    input: { ...parseJson(op.input_json, {}), action: op.action_type }, state: op.state,
    by: String(op.actor_discord_id), byName: op.actor_name, at: op.created_at
  })) });
});

router.post('/admin/clans/manage', requireAdmin, requireCsrf, async (req, res) => {
  const clanId = int(req.body?.clanId, 1, Number.MAX_SAFE_INTEGER);
  const requestId = text(req.body?.requestId, 36);
  const input = {
    clanId,
    action: text(req.body?.action, 20),
    discordId: text(req.body?.discordId || req.body?.userId, 22),
    name: text(req.body?.name, 50),
    tag: text(req.body?.tag, 4).toUpperCase(),
    avatarUrl: text(req.body?.avatarUrl, 2000),
    role: text(req.body?.role, 20),
    confirmTag: text(req.body?.confirmTag, 4).toUpperCase()
  };
  if (!clanId || !UUID_RE.test(requestId)) return res.status(400).json({ error: 'The clan action request is invalid.' });
  const inputHash = createHash('sha256').update(JSON.stringify(input)).digest('hex');
  const actorId = req.auth.user.discordId;
  const runAction = async () => withTransaction(async (connection) => {
    const [prior] = await connection.execute('SELECT actor_discord_id, input_hash, result_json FROM clan_management_operations WHERE request_id=? LIMIT 1 FOR UPDATE', [requestId]);
    if (prior.length) {
      if (String(prior[0].actor_discord_id) !== String(actorId) || prior[0].input_hash !== inputHash) throw routeError('This action request ID was already used for a different request.', 409);
      return parseJson(prior[0].result_json, { ok: true });
    }
    const [clanRows] = await connection.execute('SELECT id, name, tag, leader_user_id FROM clans WHERE id=? LIMIT 1 FOR UPDATE', [clanId]);
    if (!clanRows.length) throw routeError('Clan not found.', 404);
    const clan = clanRows[0];
    let result = { ok: true };
    if (input.action === 'rename') {
      let avatarUrl = null;
      if (input.avatarUrl) {
        try {
          const avatar = new URL(input.avatarUrl);
          if (avatar.protocol !== 'https:' || avatar.username || avatar.password) throw new Error();
          avatarUrl = avatar.href;
        } catch { throw routeError('The clan avatar must be a valid HTTPS URL.'); }
      }
      if (input.name.length < 2 || !/^[A-Z0-9_]{3,4}$/.test(input.tag)) throw routeError('Enter a clan name and a 3–4 character clan tag.');
      await connection.execute('UPDATE clans SET name=?, tag=?, avatar_url=? WHERE id=?', [input.name, input.tag, avatarUrl, clanId]);
    } else if (input.action === 'add') {
      if (!/^\d{16,22}$/.test(input.discordId)) throw routeError('Enter a valid Discord ID.');
      const [users] = await connection.execute('SELECT id FROM app_users WHERE discord_id=? LIMIT 1', [input.discordId]);
      if (!users.length) throw routeError('This Discord player has not signed in to RED PVP yet.', 404);
      const memberId = Number(users[0].id);
      if (Number(clan.leader_user_id) === memberId) throw routeError('This player is already the clan leader.', 409);
      const [memberships] = await connection.execute('SELECT clan_id FROM clan_members WHERE user_id=? LIMIT 1', [memberId]);
      if (memberships.length) throw routeError('This player already belongs to a clan.', 409);
      const [countRows] = await connection.execute('SELECT COUNT(*) AS count FROM clan_members WHERE clan_id=?', [clanId]);
      if (Number(countRows[0].count) >= 15) throw routeError('This clan already has the maximum of 15 members.', 409);
      await connection.execute("INSERT INTO clan_members (clan_id,user_id,role) VALUES (?,?, 'member')", [clanId, memberId]);
      result = { ok: true, memberAdded: true };
    } else if (input.action === 'remove' || input.action === 'transfer' || input.action === 'role') {
      if (!/^\d{16,22}$/.test(input.discordId)) throw routeError('Enter a valid Discord ID.');
      const [users] = await connection.execute('SELECT id FROM app_users WHERE discord_id=? LIMIT 1', [input.discordId]);
      if (!users.length) throw routeError('Discord user not found.', 404);
      const targetId = Number(users[0].id);
      const [membership] = await connection.execute('SELECT role FROM clan_members WHERE clan_id=? AND user_id=? LIMIT 1', [clanId, targetId]);
      if (!membership.length) throw routeError('This player is not a member of this clan.', 404);
      if (input.action === 'remove') {
        if (Number(clan.leader_user_id) === targetId) throw routeError('Transfer leadership before removing the clan leader.', 409);
        await connection.execute('DELETE FROM clan_members WHERE clan_id=? AND user_id=?', [clanId, targetId]);
        result = { ok: true, memberRemoved: true, discordRoles: 'not-synchronized' };
      } else if (input.action === 'transfer') {
        if (Number(clan.leader_user_id) !== targetId && clan.leader_user_id) {
          await connection.execute("INSERT IGNORE INTO clan_members (clan_id,user_id,role) VALUES (?,?,'member')", [clanId, clan.leader_user_id]);
        }
        await connection.execute('UPDATE clans SET leader_user_id=? WHERE id=?', [targetId, clanId]);
        await connection.execute("UPDATE clan_members SET role='member' WHERE clan_id=? AND user_id=?", [clanId, targetId]);
        result = { ok: true, leadershipTransferred: true, discordRoles: 'not-synchronized' };
      } else {
        if (Number(clan.leader_user_id) === targetId) throw routeError('The clan leader role is managed by leadership transfer.', 409);
        if (!['member', 'co_leader'].includes(input.role)) throw routeError('Choose Member or Co-Leader.');
        await connection.execute('UPDATE clan_members SET role=? WHERE clan_id=? AND user_id=?', [input.role, clanId, targetId]);
        result = { ok: true, role: input.role, discordRoles: 'not-synchronized' };
      }
    } else if (input.action === 'delete') {
      if (input.confirmTag !== String(clan.tag).toUpperCase()) throw routeError('The confirmation tag does not match this clan.', 409);
      await connection.execute('DELETE FROM clans WHERE id=?', [clanId]);
      result = { ok: true, discordResources: 'not-synchronized' };
    } else {
      throw routeError('Unsupported clan operation.');
    }
    await connection.execute(
      `INSERT INTO clan_management_operations (request_id,clan_id,clan_name,action_type,actor_discord_id,actor_name,input_hash,input_json,result_json,state)
       VALUES (?,?,?,?,?,?,?,CAST(? AS JSON),CAST(? AS JSON),'complete')`,
      [requestId, clanId, clan.name, input.action, String(actorId), text(req.auth.user.username, 80), inputHash, JSON.stringify(input), JSON.stringify(result)]
    );
    return result;
  });
  try {
    res.json(await runAction());
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      const [prior] = await query('SELECT actor_discord_id,input_hash,result_json FROM clan_management_operations WHERE request_id=? LIMIT 1', [requestId]);
      if (prior.length && String(prior[0].actor_discord_id) === String(actorId) && prior[0].input_hash === inputHash) return res.json(parseJson(prior[0].result_json, { ok: true }));
      return res.status(409).json({ error: prior.length ? 'This action request ID was already used for a different request.' : 'The clan tag or membership conflicts with existing data.' });
    }
    const status = Number.isInteger(error.status) ? error.status : 500;
    res.status(status).json({ error: status < 500 ? error.message : 'The clan operation could not be completed.' });
  }
});

router.get('/admin/promos', requireStaff, async (_req, res) => {
  const promos = await query('SELECT id, code, percent_off, expires_at, max_uses, per_user, used_count, cancelled_at FROM promo_codes ORDER BY created_at DESC LIMIT 200');
  res.json({ promos: promos.map((row) => {
    const used = Number(row.used_count);
    const maxUses = row.max_uses === null ? null : Number(row.max_uses);
    const expired = new Date(row.expires_at).getTime() <= Date.now();
    const status = row.cancelled_at ? 'cancelled' : expired ? 'expired' : maxUses !== null && used >= maxUses ? 'exhausted' : 'active';
    return { id: Number(row.id), code: row.code, percent: Number(row.percent_off), expiresAt: row.expires_at, maxUses, perUser: Number(row.per_user), used, uses: used, cancelled: Boolean(row.cancelled_at), active: status === 'active', status };
  }), logs: { pending: 0, error: null } });
});

router.post('/admin/promos/create', requireAdmin, requireCsrf, async (req, res) => {
  const code = text(req.body?.code, 32).toUpperCase();
  const percent = int(req.body?.percent, 1, 100);
  const expiry = new Date(req.body?.expiresAt);
  const maxUses = req.body?.maxUses === null || req.body?.maxUses === '' ? null : int(req.body?.maxUses, 1, 1_000_000);
  const perUser = int(req.body?.perUser, 1, 1_000_000);
  if (!/^[A-Z0-9_-]{3,32}$/.test(code) || percent === null || !Number.isFinite(expiry.getTime()) || expiry <= new Date() || (req.body?.maxUses != null && maxUses === null) || perUser === null) return res.status(400).json({ error: 'Promo details are invalid.' });
  await query('INSERT INTO promo_codes (code, percent_off, expires_at, max_uses, per_user, created_by) VALUES (?, ?, ?, ?, ?, ?)', [code, percent, expiry, maxUses, perUser, req.auth.user.id]);
  res.status(201).json({ ok: true });
});

router.post('/admin/promos/cancel', requireAdmin, requireCsrf, async (req, res) => {
  const id = int(req.body?.id, 1, Number.MAX_SAFE_INTEGER);
  if (!id) return res.status(400).json({ error: 'Invalid promo ID.' });
  await query('UPDATE promo_codes SET cancelled_at=UTC_TIMESTAMP() WHERE id=? AND cancelled_at IS NULL', [id]);
  res.json({ ok: true });
});

router.post('/admin/promos/retry', requireStaff, requireCsrf, async (_req, res) => {
  res.json({ ok: true, retried: 0, message: 'There are no queued notification jobs to retry.' });
});

router.post('/admin/rules', requireAdmin, requireCsrf, async (req, res) => {
  const body = text(req.body?.text, 20_000);
  const categories = req.body?.categories;
  if (!Array.isArray(categories) || categories.length > 200 || Buffer.byteLength(JSON.stringify(categories)) > 100_000) return res.status(400).json({ error: 'Rule categories are invalid.' });
  await query(
    `INSERT INTO site_rules (rule_key, body_text, categories, updated_by) VALUES ('main', ?, CAST(? AS JSON), ?)
     ON DUPLICATE KEY UPDATE body_text=VALUES(body_text), categories=VALUES(categories), updated_by=VALUES(updated_by)`,
    [body, JSON.stringify(categories), req.auth.user.id]
  );
  res.json({ ok: true });
});

router.post('/admin/requests/review', requireStaff, requireCsrf, async (req, res) => {
  const id = int(req.body?.id, 1, Number.MAX_SAFE_INTEGER);
  const status = text(req.body?.status, 24);
  if (!id || !['approved', 'rejected'].includes(status)) return res.status(400).json({ error: 'Choose an available review result.' });
  const rows = await query('SELECT id, status, request_type FROM community_requests WHERE id=? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Request not found.' });
  if (!['pending', 'approved', 'rejected'].includes(rows[0].status)) return res.status(409).json({ error: 'This request can no longer be reviewed.' });
  const effectError = status === 'approved' && rows[0].request_type === 'whitelist'
    ? 'No MTA game-server integration is connected to apply this approval in-game.'
    : null;
  await query('UPDATE community_requests SET status=?, reviewed_by=?, reviewed_at=UTC_TIMESTAMP(), review_attempt=CAST(? AS JSON), effect_error=? WHERE id=?', [status, req.auth.user.id, JSON.stringify({ decision: status, state: 'saved', at: new Date().toISOString() }), effectError, id]);
  const notification = await notifyRequest(id);
  res.json({ ok: true, status, notification: notification.status, effectError });
});

router.post('/admin/requests/delete', requireAdmin, requireCsrf, async (req, res) => {
  const id = int(req.body?.id, 1, Number.MAX_SAFE_INTEGER);
  if (!id) return res.status(400).json({ error: 'Invalid request ID.' });
  await query('DELETE FROM community_requests WHERE id=?', [id]);
  res.json({ ok: true });
});

router.post('/admin/requests/notify', requireStaff, requireCsrf, async (req, res) => {
  const id = int(req.body?.id, 1, Number.MAX_SAFE_INTEGER);
  if (!id) return res.status(400).json({ error: 'Invalid request ID.' });
  const result = await notifyRequest(id);
  if (result.status !== 'sent') return res.status(502).json({ error: result.error || 'Discord notification failed.' });
  res.json({ ok: true, notification: result.status });
});


router.post('/admin/users/link-game', requireAdmin, requireCsrf, async (req, res) => {
  const discordId = text(req.body?.discordId, 22);
  const gameUsername = text(req.body?.gameUsername, 45);
  if (!/^\d{16,22}$/.test(discordId) || !/^[A-Za-z0-9_]{1,24}$/.test(gameUsername)) return res.status(400).json({ error: 'Enter a valid Discord ID and MTA username.' });
  const users = await query('SELECT id FROM app_users WHERE discord_id=? LIMIT 1', [discordId]);
  if (!users.length) return res.status(404).json({ error: 'The Discord user has not signed in to RED PVP yet.' });
  const duplicate = await query('SELECT discord_id FROM app_users WHERE game_username=? AND id<>? LIMIT 1', [gameUsername, users[0].id]);
  if (duplicate.length) return res.status(409).json({ error: 'That MTA username is already linked to another RED PVP account.' });
  await query('UPDATE app_users SET game_username=? WHERE id=?', [gameUsername, users[0].id]);
  res.json({ ok: true, gameUsername });
});

export default router;
