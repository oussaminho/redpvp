import mysql from 'mysql2/promise';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

let pool;
const migrationsDir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

export function getPool() {
  if (!pool) {
    if (!process.env.DATABASE_URL) throw new Error('Managed database is not configured.');
    pool = mysql.createPool(process.env.DATABASE_URL);
  }
  return pool;
}

export async function query(sql, params = []) {
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

export async function withTransaction(callback) {
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function initializeDatabase() {
  const db = getPool();
  await db.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version VARCHAR(100) NOT NULL PRIMARY KEY,
    applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  const [applied] = await db.execute('SELECT version FROM schema_migrations');
  const known = new Set(applied.map((row) => row.version));
  const version = '001_initial';
  if (!known.has(version)) {
    const sql = await readFile(path.join(migrationsDir, `${version}.sql`), 'utf8');
    const statements = sql.split(';').map((part) => part.trim()).filter(Boolean);
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      for (const statement of statements) await connection.query(statement);
      await connection.execute('INSERT INTO schema_migrations (version) VALUES (?)', [version]);
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
  return true;
}

export async function closeDatabase() {
  if (pool) {
    const current = pool;
    pool = undefined;
    await current.end();
  }
}
