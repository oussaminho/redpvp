CREATE TABLE IF NOT EXISTS app_users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  discord_id VARCHAR(32) NOT NULL UNIQUE,
  username VARCHAR(80) NOT NULL,
  avatar_url VARCHAR(255) NULL,
  game_username VARCHAR(45) NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'player',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role),
  UNIQUE KEY uq_user_game_username (game_username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  csrf_token CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sessions_user (user_id),
  INDEX idx_sessions_expiry (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oauth_states (
  state_hash CHAR(64) NOT NULL PRIMARY KEY,
  return_to VARCHAR(255) NOT NULL,
  origin VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_oauth_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_wallets (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  balance_cents BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  order_id CHAR(36) NULL,
  kind VARCHAR(30) NOT NULL,
  cents BIGINT NOT NULL,
  note VARCHAR(255) NOT NULL,
  idempotency_key VARCHAR(80) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_wallet_idempotency (user_id, idempotency_key),
  INDEX idx_wallet_ledger_user (user_id, created_at),
  CONSTRAINT fk_ledger_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS red_orders (
  id CHAR(36) NOT NULL PRIMARY KEY,
  order_number BIGINT UNSIGNED NOT NULL AUTO_INCREMENT UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  request_id CHAR(36) NOT NULL,
  player_name VARCHAR(45) NOT NULL,
  discord_name VARCHAR(80) NOT NULL,
  order_kind VARCHAR(24) NOT NULL DEFAULT 'store',
  recipient_user_id BIGINT UNSIGNED NULL,
  method VARCHAR(16) NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'pending',
  fulfillment VARCHAR(24) NOT NULL DEFAULT 'pending',
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  subtotal_cents BIGINT NOT NULL,
  discount_cents BIGINT NOT NULL DEFAULT 0,
  total_cents BIGINT NOT NULL,
  promo_code VARCHAR(32) NULL,
  paypal_order_id VARCHAR(36) NULL,
  paypal_approval_url VARCHAR(500) NULL,
  paypal_capture_id VARCHAR(36) NULL,
  transfer_reference VARCHAR(64) NULL,
  review_note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_order_request (user_id, request_id),
  INDEX idx_orders_user (user_id, created_at),
  INDEX idx_orders_status (status, fulfillment),
  INDEX idx_orders_paypal (paypal_order_id),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES app_users(id),
  CONSTRAINT fk_order_recipient FOREIGN KEY (recipient_user_id) REFERENCES app_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS red_order_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_id CHAR(36) NOT NULL,
  product_id VARCHAR(64) NOT NULL,
  product_name VARCHAR(120) NOT NULL,
  plan_id VARCHAR(32) NOT NULL,
  plan_label VARCHAR(64) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  car_name VARCHAR(100) NULL,
  skin_name VARCHAR(100) NULL,
  weapon_name VARCHAR(100) NULL,
  unit_cents BIGINT NOT NULL,
  total_cents BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_order_items_order (order_id),
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES red_orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stored_user_files (
  id CHAR(36) NOT NULL PRIMARY KEY,
  order_id CHAR(36) NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  file_kind VARCHAR(24) NOT NULL,
  object_key VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_files_order (order_id, file_kind),
  CONSTRAINT fk_files_order FOREIGN KEY (order_id) REFERENCES red_orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_files_user FOREIGN KEY (user_id) REFERENCES app_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS promo_codes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(32) NOT NULL UNIQUE,
  percent_off TINYINT UNSIGNED NOT NULL,
  expires_at DATETIME NOT NULL,
  max_uses INT UNSIGNED NULL,
  per_user INT UNSIGNED NOT NULL DEFAULT 1,
  used_count INT UNSIGNED NOT NULL DEFAULT 0,
  cancelled_at DATETIME NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_promos_active (cancelled_at, expires_at),
  CONSTRAINT fk_promos_creator FOREIGN KEY (created_by) REFERENCES app_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS promo_uses (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  promo_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  order_id CHAR(36) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_promo_order (order_id),
  INDEX idx_promo_user (promo_id, user_id),
  CONSTRAINT fk_promo_use_code FOREIGN KEY (promo_id) REFERENCES promo_codes(id),
  CONSTRAINT fk_promo_use_user FOREIGN KEY (user_id) REFERENCES app_users(id),
  CONSTRAINT fk_promo_use_order FOREIGN KEY (order_id) REFERENCES red_orders(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS community_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  request_type VARCHAR(32) NOT NULL,
  payload JSON NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'pending',
  notification_status VARCHAR(24) NOT NULL DEFAULT 'not_sent',
  review_attempt JSON NULL,
  effect_error VARCHAR(500) NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_requests_user (user_id, created_at),
  INDEX idx_requests_status (request_type, status),
  CONSTRAINT fk_requests_user FOREIGN KEY (user_id) REFERENCES app_users(id),
  CONSTRAINT fk_requests_reviewer FOREIGN KEY (reviewed_by) REFERENCES app_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_rules (
  rule_key VARCHAR(32) NOT NULL PRIMARY KEY,
  body_text MEDIUMTEXT NOT NULL,
  categories JSON NOT NULL,
  updated_by BIGINT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_rules_user FOREIGN KEY (updated_by) REFERENCES app_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS staff_profiles (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  game_name VARCHAR(80) NULL,
  serial_hash CHAR(64) NULL,
  role_names JSON NOT NULL,
  discord_roles JSON NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_staff_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  tag VARCHAR(12) NOT NULL UNIQUE,
  leader_user_id BIGINT UNSIGNED NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  avatar_url VARCHAR(2000) NULL,
  guild_id VARCHAR(32) NULL,
  chat_channel_id VARCHAR(32) NULL,
  voice_channel_id VARCHAR(32) NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_clan_leader FOREIGN KEY (leader_user_id) REFERENCES app_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clan_members (
  clan_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'member',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (clan_id, user_id),
  UNIQUE KEY uq_clan_member_user (user_id),
  CONSTRAINT fk_clan_member_clan FOREIGN KEY (clan_id) REFERENCES clans(id) ON DELETE CASCADE,
  CONSTRAINT fk_clan_member_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clan_management_operations (
  request_id CHAR(36) NOT NULL PRIMARY KEY,
  clan_id BIGINT UNSIGNED NOT NULL,
  clan_name VARCHAR(80) NOT NULL,
  action_type VARCHAR(24) NOT NULL,
  actor_discord_id VARCHAR(32) NOT NULL,
  actor_name VARCHAR(80) NOT NULL,
  input_hash CHAR(64) NOT NULL,
  input_json JSON NOT NULL,
  result_json JSON NOT NULL,
  state VARCHAR(16) NOT NULL DEFAULT 'complete',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_clan_ops_history (clan_id, created_at),
  INDEX idx_clan_ops_actor (actor_discord_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS shield_verifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  ip_hash CHAR(64) NOT NULL,
  status VARCHAR(24) NOT NULL,
  expires_at DATETIME NULL,
  external_reference VARCHAR(128) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_shield_user_ip (user_id, ip_hash),
  INDEX idx_shield_expiry (expires_at),
  CONSTRAINT fk_shield_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS game_rankings (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  playtime_hours INT UNSIGNED NOT NULL DEFAULT 0,
  score BIGINT NOT NULL DEFAULT 0,
  rank_label VARCHAR(48) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_rank_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
