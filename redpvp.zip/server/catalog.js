const cars = [
  ['car-bmw-m4', 'BMW M4', 'assets/vip-car-bmw-m4.png'],
  ['car-audi-rs7', 'Audi RS7', 'assets/vip-car-audi-rs7.png'],
  ['car-bentley-continental', 'Bentley Continental', 'assets/vip-car-bentley-continental.png'],
  ['car-bmw-m8', 'BMW M8', 'assets/vip-car-bmw-m8.png'],
  ['car-porsche-911-gt3', 'Porsche 911 GT3', 'assets/vip-car-porsche-911-gt3.png'],
  ['car-mercedes-amg-gt', 'Mercedes AMG GT', 'assets/vip-car-mercedes-amg-gt.png'],
  ['car-lamborghini-huracan', 'Lamborghini Huracan', 'assets/vip-car-lamborghini-huracan.png'],
  ['car-ferrari-488', 'Ferrari 488', 'assets/vip-car-ferrari-488.png'],
  ['car-nissan-gt-r', 'Nissan GT-R', 'assets/vip-car-nissan-gt-r.png'],
  ['car-rolls-royce-wraith', 'Rolls-Royce Wraith', 'assets/vip-car-rolls-royce-wraith.png'],
  ['car-yamaha-r1', 'Yamaha R1', 'assets/vip-yamaha-r1.png'],
  ['car-bmw-s1000-rr', 'BMW S1000 RR', 'assets/vip-bmw-s1000-rr.png'],
  ['car-ducati-panigale-v4-s', 'Ducati Panigale V4 S', 'assets/vip-ducati-panigale-v4-s.png']
];
const weapons = [
  ['weapon-vava', 'Vandal', 'assets/vip-weapon-vava.png'],
  ['weapon-arma', 'Carabine Rifle', 'assets/vip-weapon-arma.png'],
  ['weapon-vector', 'Victor', 'assets/vip-weapon-vector.png'],
  ['weapon-glock-19-white', 'Glock', 'assets/vip-weapon-glock-19-white.png'],
  ['weapon-suppressed-smg', 'Sup Smg', 'assets/vip-weapon-suppressed-smg.png'],
  ['weapon-ap-pistol', 'Ap Pistol', 'assets/appistol.png']
];
const skins = [['cj', 'CJ', 'assets/cj-custom-skins.png']];
const plans = (items) => items.map(([id, label, amount]) => ({ id, label, cents: amount * 100 }));
const standard = plans([['2w', '2 Weeks', 4], ['1m', '1 Month', 7], ['3m', '3 Months', 18]]);
const weaponPlans = plans([['2w', '2 Weeks', 3], ['1m', '1 Month', 5], ['3m', '3 Months', 13]]);

export const products = [
  { id: 'silver', name: 'Silver VIP Pack', type: 'vip', includesSkin: true, includesWeapon: false, plans: plans([['2w', '2 Weeks', 6], ['1m', '1 Month', 9], ['3m', '3 Months', 20]]) },
  { id: 'custom', name: 'Platinum VIP Pack', type: 'vip', includesSkin: false, includesWeapon: true, plans: plans([['2w', '2 Weeks', 6], ['1m', '1 Month', 10], ['3m', '3 Months', 26]]) },
  { id: 'gold', name: 'Gold VIP Pack', type: 'vip', includesSkin: true, includesWeapon: true, plans: plans([['2w', '2 Weeks', 8], ['1m', '1 Month', 13], ['3m', '3 Months', 29]]) },
  { id: 'custom-skin', name: 'Custom Skin', type: 'skins', customUpload: true, plans: plans([['permanent', 'Permanent', 5]]) },
  { id: 'cj', name: 'CJ', type: 'skins', plans: plans([['permanent', 'Permanent', 5]]) },
  ...cars.map(([id, name, image]) => ({ id, name, type: 'cars', image, plans: standard })),
  ...weapons.map(([id, name, image]) => ({ id, name, type: 'weapons', image, plans: weaponPlans })),
  ...[5, 10, 20, 30].map((amount) => ({ id: `donation-${amount}`, name: `VIP Donation · $${amount}`, type: 'donations', plans: plans([['once', 'One-time donation', amount]]) }))
];

export const carNames = cars.map(([, name]) => name);
export const skinNames = skins.map(([, name]) => name);
export const weaponNames = weapons.map(([, name]) => name);
export const productById = new Map(products.map((product) => [product.id, product]));

export function normalizeCart(input) {
  if (!Array.isArray(input) || input.length < 1 || input.length > 30) throw new Error('The cart is invalid.');
  return input.map((raw) => {
    if (!raw || typeof raw !== 'object') throw new Error('The cart contains an invalid item.');
    const product = productById.get(String(raw.id || ''));
    if (!product) throw new Error('A product in your cart is unavailable.');
    const qty = Number(raw.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > (product.customUpload ? 3 : 99)) throw new Error('The quantity is invalid.');
    const plan = product.plans.find((entry) => entry.id === String(raw.planId || ''));
    if (!plan) throw new Error('The selected plan is unavailable.');
    const car = product.type === 'cars' ? product.name : (product.type === 'vip' ? String(raw.car || '') : '');
    const skin = product.type === 'skins' ? product.name : (product.includesSkin ? String(raw.skin || '') : '');
    const weapon = product.type === 'weapons' ? product.name : (product.includesWeapon ? String(raw.weapon || '') : '');
    if (product.type === 'vip' && !carNames.includes(car)) throw new Error('Choose a valid VIP vehicle.');
    if (product.includesSkin && !skinNames.includes(skin)) throw new Error('Choose a valid included skin.');
    if (product.includesWeapon && !weaponNames.includes(weapon)) throw new Error('Choose a valid included weapon.');
    const unitCents = plan.cents;
    return {
      id: product.id,
      name: product.name,
      type: product.type,
      planId: plan.id,
      planLabel: plan.label,
      qty,
      car,
      skin,
      weapon,
      customUpload: Boolean(product.customUpload),
      unitCents,
      totalCents: unitCents * qty
    };
  });
}

export function totalCartCents(items) {
  return items.reduce((total, item) => total + item.totalCents, 0);
}
