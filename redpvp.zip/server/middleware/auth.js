import { timingSafeEqual } from 'node:crypto';
import { getSession } from '../services/sessions.js';

export async function attachUser(req, _res, next) {
  try {
    req.auth = await getSession(req.headers.cookie || '');
  } catch (error) {
    req.auth = null;
    req.authError = error;
  }
  next();
}

export function requireUser(req, res, next) {
  if (req.authError) return res.status(503).json({ error: 'Account service is temporarily unavailable.' });
  if (!req.auth?.user) return res.status(401).json({ error: 'Sign in with Discord to continue.' });
  next();
}

export function requireCsrf(req, res, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const expected = req.auth?.csrfToken;
  const supplied = req.get('X-CSRF-Token');
  if (!expected || !supplied) return res.status(403).json({ error: 'Your session expired. Refresh and try again.' });
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(403).json({ error: 'Your session expired. Refresh and try again.' });
  next();
}

export function requireStaff(req, res, next) {
  if (req.authError) return res.status(503).json({ error: 'Account service is temporarily unavailable.' });
  if (!req.auth?.user) return res.status(401).json({ error: 'Sign in with Discord to continue.' });
  if (!['staff', 'admin'].includes(req.auth.user.role)) return res.status(403).json({ error: 'This action requires staff access.' });
  next();
}

export function requireAdmin(req, res, next) {
  if (req.authError) return res.status(503).json({ error: 'Account service is temporarily unavailable.' });
  if (!req.auth?.user) return res.status(401).json({ error: 'Sign in with Discord to continue.' });
  if (req.auth.user.role !== 'admin') return res.status(403).json({ error: 'This action requires administrator access.' });
  next();
}
