import test from 'node:test';
import assert from 'node:assert/strict';
import { futureExpiry, getMtaStatus } from '../server/services/mta.js';

test('reports an unconfigured MTA server as unavailable without inventing player counts', async () => {
  const previous = process.env.MTA_STATUS_URL;
  delete process.env.MTA_STATUS_URL;
  const status = await getMtaStatus();
  assert.equal(status.state, 'unavailable');
  assert.equal(status.configured, false);
  assert.equal(status.players, null);
  assert.equal(status.capacity, null);
  if (previous !== undefined) process.env.MTA_STATUS_URL = previous;
});

test('requires an explicit future ISO expiry for Shield decisions', () => {
  const now = Date.UTC(2030, 0, 1, 0, 0, 0);
  assert.equal(futureExpiry(undefined, now), null);
  assert.equal(futureExpiry('not-a-date', now), null);
  assert.equal(futureExpiry('2030-01-01T00:00:00.000Z', now), null);
  assert.equal(futureExpiry('2030-01-01T00:01:00.000Z', now)?.toISOString(), '2030-01-01T00:01:00.000Z');
});
