import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeBase64, isZip, receiptType, validateSkinArchive, zipEntries } from '../server/uploads/validation.js';

function makeZip(names) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  for (const name of names) {
    const nameBytes = Buffer.from(name);
    const data = Buffer.from('file');
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBytes.length, 26);
    localParts.push(local, nameBytes, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBytes.length, 28);
    central.writeUInt32LE(localOffset, 42);
    centralParts.push(central, nameBytes);
    localOffset += local.length + nameBytes.length + data.length;
  }
  const central = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(names.length, 8);
  end.writeUInt16LE(names.length, 10);
  end.writeUInt32LE(central.length, 12);
  end.writeUInt32LE(localOffset, 16);
  return Buffer.concat([...localParts, central, end]);
}

test('accepts PNG, JPEG and WebP signatures and rejects unrelated file bytes', () => {
  assert.equal(receiptType(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), 'image/png');
  assert.equal(receiptType(Buffer.from([255, 216, 255, 0])), 'image/jpeg');
  assert.equal(receiptType(Buffer.from('RIFF0000WEBPdata')), 'image/webp');
  assert.equal(receiptType(Buffer.from('not an image')), null);
});

test('accepts bounded base64 and data URLs while rejecting malformed or oversized input', () => {
  assert.deepEqual(decodeBase64(Buffer.from('hello').toString('base64'), 8), Buffer.from('hello'));
  const exactLimit = Buffer.alloc(12, 7);
  assert.deepEqual(decodeBase64(`data:image/png;base64,${exactLimit.toString('base64')}`, 12), exactLimit);
  assert.throws(() => decodeBase64('not base64!', 100));
  assert.throws(() => decodeBase64(Buffer.from('0123456789').toString('base64'), 4));
  assert.throws(() => decodeBase64(`data:image/png;base64,${Buffer.alloc(13).toString('base64')}`, 12));
});

test('reads safe DFF and TXD ZIP entries and rejects path traversal', () => {
  const zip = makeZip(['player.dff', 'player.txd']);
  assert.equal(isZip(zip), true);
  assert.deepEqual(zipEntries(zip), ['player.dff', 'player.txd']);
  assert.equal(validateSkinArchive(zip), zip);
  assert.throws(() => zipEntries(makeZip(['../evil.dff', 'player.txd'])));
  assert.throws(() => validateSkinArchive(makeZip(['player.dff'])));
  assert.throws(() => validateSkinArchive(makeZip(['player.dff', 'readme.txt'])));
});
