import test from 'node:test';
import assert from 'node:assert/strict';
import { clientOrigin, int, text } from '../server/utils.js';

test('normalizes text and accepts only safe integer ranges', () => {
  assert.equal(text('  hello  ', 10), 'hello');
  assert.equal(int('42', 1, 100), 42);
  assert.equal(int('101', 1, 100), null);
  assert.equal(int('1.5', 1, 100), null);
});

test('uses the browser origin and enforces an exact configured allowlist', () => {
  const previous = process.env.REDPVP_ALLOWED_ORIGINS;
  process.env.REDPVP_ALLOWED_ORIGINS = 'https://preview.example';
  const req = { body: { origin: 'https://preview.example/shop?x=1' }, query: {}, get: () => '' };
  assert.equal(clientOrigin(req), 'https://preview.example');
  req.body.origin = 'https://preview.example.attacker.test';
  assert.equal(clientOrigin(req), '');
  if (previous === undefined) delete process.env.REDPVP_ALLOWED_ORIGINS;
  else process.env.REDPVP_ALLOWED_ORIGINS = previous;
});
