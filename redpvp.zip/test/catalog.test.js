import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeCart, totalCartCents } from '../server/catalog.js';

test('normalizes a VIP cart from server-owned product and plan data', () => {
  const [item] = normalizeCart([{ id: 'silver', planId: '1m', qty: 2, car: 'BMW M4', skin: 'CJ', unitCents: 1 }]);
  assert.equal(item.unitCents, 900);
  assert.equal(item.totalCents, 1800);
  assert.equal(totalCartCents([item]), 1800);
  assert.equal(item.name, 'Silver VIP Pack');
});

test('rejects unknown products, plans, quantities, and VIP choices', () => {
  assert.throws(() => normalizeCart([{ id: 'unknown', planId: '1m', qty: 1 }]));
  assert.throws(() => normalizeCart([{ id: 'silver', planId: '1m', qty: 0, car: 'BMW M4', skin: 'CJ' }]));
  assert.throws(() => normalizeCart([{ id: 'silver', planId: 'forever', qty: 1, car: 'BMW M4', skin: 'CJ' }]));
  assert.throws(() => normalizeCart([{ id: 'silver', planId: '1m', qty: 1, car: 'client-selected-car', skin: 'CJ' }]));
});
