# RED PVP

موقع RED PVP مبني على الملفات الأصلية الموجودة في `public/`، مع خادم Node.js/Express، قاعدة بيانات MySQL المُدارة، OAuth عبر Discord، وسير الطلبات ورفع الملفات. ملفات الصور والخطوط وCSS/JavaScript الأصلية محفوظة كما هي. ملفات JavaScript وCSS ذات لاحقة إصدار تُقدّم بنوع MIME الصحيح بواسطة Express.

## التشغيل

يتطلب Node.js 22 وpnpm 11.25.0. في بيئة WebDev المُدارة توفر المنصة `DATABASE_URL` و`MANUS_API_URL` و`MANUS_API_KEY`. شغّل `pnpm install` ثم `pnpm dev`. الخدمة تستمع على `PORT` أو `3000` وعلى `0.0.0.0`. نقطة الصحة العامة هي `/healthz`؛ تبقى بحالة بدء التشغيل حتى تنجح migrations الإضافية.

تضيف migration `server/db/migrations/001_initial.sql` جداول التطبيق فقط ولا تحذف أو تستبدل جداول أو بيانات. قاعدة WebDev نفسها مشتركة بين Preview والنشر، لذلك يجب التعامل مع أي بيانات تُكتب من التطبيق كبيانات حقيقية.

## أسرار وإعدادات لازمة

انسخ `.env.example` عند التشغيل المحلي فقط، ولا تضع أي قيمة سرية داخل Git. استخدم بطاقة Secrets في WebDev لقيم التشغيل. يلزم تهيئة `REDPVP_SESSION_SECRET` (عشوائي قوي لا يقل عن 32 بايت)، و`DISCORD_CLIENT_ID` و`DISCORD_CLIENT_SECRET`، و`REDPVP_ADMIN_DISCORD_IDS` لمعرّفات المديرين. أضف callback الكامل لأصل Preview وأصل الموقع المنشور إلى Discord Developer Portal. عادةً اترك `DISCORD_REDIRECT_URI` غير مضبوط كي يُشتق callback من أصل المتصفح؛ لا تضبطه إلا إذا أردت callback ثابتاً ومطابقاً للقيمة المسجلة لدى Discord. إذا استخدمت `REDPVP_ALLOWED_ORIGINS` كقائمة سماح صريحة، أدرج فيها أصل Preview وكل أصل منشور سيستخدم تسجيل الدخول.

ملف جلسة التطبيق يستخدم `SameSite=None; Secure` افتراضياً حتى يعمل في Preview HTTPS المضمّن. لا تضبط `APP_COOKIE_SECURE=false` إلا عند التطوير المحلي على HTTP صريح.

## المتجر والدفع

مصدر السعر الوحيد في الخادم هو `server/catalog.js`، ولا تُقبل قيمة سعر مرسلة من المتصفح. PayPal يستخدم Orders v2: التطبيق ينشئ طلباً من الخادم، ويرجع رابط الموافقة، ثم لا يضع الطلب بحالة مدفوع حتى يؤكد PayPal capture حالة المبلغ والعملة المطابقين. اختبر أولاً باستخدام `PAYPAL_ENV=sandbox` وبيانات تطبيق sandbox، ولا تستخدم بيانات live إلا بعد اعتماد المالك.

تحويل CIH يدوي، وليس تأكيد دفع إلكتروني. لتفعيله، أدخل اسم الحساب ورقمه و`CIH_RATE` (عدد MAD لكل USD) بعد أن يحددها المالك. يُحفظ الإيصال بصورة PNG/JPEG/WebP بحجم أقصى 3 MB ويظل الطلب بانتظار مراجعة الموظف. طلبات رصيد المحفظة لا تُضاف للمستفيد قبل اعتماد الموظف. لوحة المراجعة محمية على `/admin/payments`.

تُحفظ ملفات الإيصالات وملفات custom-skin في تخزين WebDev الدائم. يسجل MySQL ملكية الملف ولا تُستخدم ملفات محلية مؤقتة. ZIP الجلود لا يتجاوز 10 MB ويجب أن يحتوي بالضبط على ملف DFF واحد وTXD واحد؛ الحجم الموسع محدود بـ50 MB. ملفات الإيصالات والجلود تُقدّم عبر endpoint يتحقق من ملكية الطلب أو من صلاحية الموظف.

مواصفات المزود المستخدمة: [PayPal Orders API](https://developer.paypal.com/api/rest/integration/orders-api)، [PayPal Capture Order](https://developer.paypal.com/api/orders/v2/orders-capture)، [Cloudflare Turnstile server-side validation](https://developers.cloudflare.com/turnstile/get-started/server-side-validation/)، WebDev project storage returns stable `/manus-storage/<key>` object paths through server-authenticated presigned transfers.

## تكامل خادم MTA

لا يحتوي الأرشيف على API أو إضافة MTA Server أو بيانات وصول للخادم. لذلك لا يزعم التطبيق أن الطلب أو التحقق أضاف لاعباً فعلياً إلى خادم اللعبة. إدارة عضوية الكلان هنا تعدّل قاعدة RED PVP فقط؛ مزامنة أدوار أو قنوات Discord تحتاج إعداد بوت/سيرفر Discord ولا ينفذها هذا backend. حالة الخادم تنتظر `MTA_STATUS_URL` ‏(HTTPS GET يرجع JSON فيه `online` منطقية و`players` و`capacity`). التحقق من Shield يحتاج Cloudflare Turnstile ومهايئ MTA خارجي. رمز Turnstile يُقبل مرة واحدة فقط وصلاحيته خمس دقائق، لذا يجب إرساله والتحقق منه خادمياً أثناء نفس محاولة التحقق. يقبل endpoint التحقق طلب POST JSON `{ "action": "verify|renew", "discordId": "...", "ip": "..." }` مع `Authorization: Bearer <MTA_API_TOKEN>` ويرجع `{ "allowed": true, "expiresAt": "ISO date مستقبلي صالح", "reference": "..." }`. يُرفض القبول إذا غاب وقت الانتهاء أو كان ماضياً. Endpoint الإلغاء يرجع `{ "revoked": true }`. يجب تنفيذ هذا العقد على إضافة MTA/خادم موثوق لدى المالك قبل إعلان التحقق فعالاً.

## فحوصات

`pnpm check` يفحص صياغة ملفات الخادم، و`pnpm test` يشغّل اختبارات Node المضمّنة. لا تتصل الاختبارات بقاعدة الإنتاج ولا تنشئ أو تحذف بيانات طلبات حقيقية.
